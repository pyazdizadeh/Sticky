(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  I.makeSpacerFromCard = (cardEl, id) => {
    const r = cardEl.getBoundingClientRect();
    const sp = document.createElement("div");
    sp.className = "sticky_spacer";
    sp.style.height = Math.max(0, Math.round(r.height)) + "px";
    sp.dataset.spacer = "1";
    sp.dataset.id = String(id || "");
    return sp;
  };

  I.removeSpacerById = (id) => {
    const safeId = String(id || "");
    const all = I.toasts.querySelectorAll('.sticky_spacer[data-spacer="1"]');
    for (let i = 0; i < all.length; i++) {
      if (String(all[i].dataset.id || "") === safeId) {
        all[i].remove();
        return;
      }
    }
  };

  // ✅ stable: tab ساده، بدون رنگ/آیکن/inline-style
  I.createPinnedTab = (model) => {
    const tab = document.createElement("div");
    tab.className = "sticky_pinnedTab";

    // کلیدها برای restore
    tab.dataset.id = String(model?.id || model?.sticky_id || "");
    tab.dataset.seq = String(model?.__seq || "");

    const titleBase = (model?.message || I.t("pinned_fallback") || "Sticky").slice(0, 22);
    const title = `#${model?.__seq || ""} • ${titleBase}`;
    tab.innerHTML = `<div class="sticky_pinnedTabTitle">${I.sanitize(title)}</div>`;

    tab.addEventListener("click", () => {
      const card = I.buildFloatingCard(model);
      I.floating.appendChild(card);
      tab.remove();
      I.removeSpacerById(model.id || model.sticky_id);
    });

    I.pinnedBar.appendChild(tab);
  };
})();