(() => {
  const root = document.getElementById("sticky_root");
  if (!root) return;

  const api = window.JOOLIOSticky || (window.JOOLIOSticky = {});
  api.__internal = api.__internal || {};
  const I = api.__internal;

  // ---- DOM refs (stable) ----
  I.root = root;
  I.toasts = document.getElementById("sticky_toasts");
  I.floating = document.getElementById("sticky_floating");
  I.pinnedBar = document.getElementById("sticky_pinnedBar");

  // ---- state ----
  I.crmHeaderId = String(root.getAttribute("data-crm-header") || "");
  I.floatingZ = 9055;
  I.cardSeq = 0;

  // ---- helpers ----
  I.getDir = () => {
    const d = root.getAttribute("dir") || document.documentElement.getAttribute("dir") || "rtl";
    return (String(d).toLowerCase() === "ltr") ? "ltr" : "rtl";
  };

  I.t = (k) => {
    // i18n loader may attach a function here
    try {
      return (typeof root.__sticky_t__ === "function") ? root.__sticky_t__(k) : k;
    } catch (_) {
      return k;
    }
  };

  I.sanitize = (s) => {
    // text-only sanitize (no HTML)
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  };

  // model factory (keeps both id and sticky_id for compatibility)
  I.createModel = (payload) => {
    const sid = String(payload?.sticky_id || payload?.id || Date.now());
    return {
      id: sid,
      sticky_id: sid,
      state: String(payload?.state || "toast"),
      kind: String(payload?.kind || "info"),
      sender: String(payload?.sender || ""),
      message: String(payload?.message || ""),
      color: String(payload?.color || "emerald"),
      todos: Array.isArray(payload?.todos) ? payload.todos : [],
      pinned_seq: Number.isFinite(payload?.pinned_seq) ? payload.pinned_seq : null,
      x: Number.isFinite(payload?.x) ? payload.x : null,
      y: Number.isFinite(payload?.y) ? payload.y : null,
      w: Number.isFinite(payload?.w) ? payload.w : null,
      h: Number.isFinite(payload?.h) ? payload.h : null
    };
  };

  // deterministic floating spawn (used by cards/api if they call it)
  let spawnIndex = 0;
  I.nextFloatingSpawnXY = () => {
    const baseX = 16;
    const baseY = 96;
    const step = 32;
    const cols = 6;

    const i = spawnIndex++;
    const x = baseX + (i % cols) * step;
    const y = baseY + Math.floor(i / cols) * step;
    return { x, y };
  };

  // ---- pinned under header (NO hardcode) ----
  function getHeaderEl() {
    const id =
      String(I.crmHeaderId || "") ||
      String(root.getAttribute("data-crm-header") || "");
    return id ? document.getElementById(id) : null;
  }

  function syncPinnedUnderHeader() {
    const bar = I.pinnedBar;
    if (!bar) return;

    const header = getHeaderEl();
    const headerBottom = header ? Math.round(header.getBoundingClientRect().bottom) : 0;

    // pinned دقیقاً زیر هدر + فاصله
    const topPx = headerBottom + 8;
    bar.style.top = topPx + "px";

    // رزرو فضا برای اینکه pinned روی محتوا/دکمه نیفته
    const barH = Math.round(bar.offsetHeight || 0);
    root.style.paddingTop = (topPx + barH + 12) + "px";
  }

  I.syncPinnedUnderHeader = syncPinnedUnderHeader;

  // observe pinned children changes (pin/restore)
  try {
    const mo = new MutationObserver(() => syncPinnedUnderHeader());
    if (I.pinnedBar) mo.observe(I.pinnedBar, { childList: true, subtree: false });
  } catch (_) {}

  // resize handling
  window.addEventListener("resize", syncPinnedUnderHeader);

  // if header size changes (optional)
  try {
    const header = getHeaderEl();
    if (header && "ResizeObserver" in window) {
      const ro = new ResizeObserver(() => syncPinnedUnderHeader());
      ro.observe(header);
    }
  } catch (_) {}

  // first sync after paint
  setTimeout(syncPinnedUnderHeader, 0);
})();