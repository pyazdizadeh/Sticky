(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  if (I.__colorInstalled) return;
  I.__colorInstalled = true;

  const COLORS = [
    { key: "emerald", label: "Emerald" },
    { key: "slate",   label: "Slate"   },
    { key: "wine",    label: "Wine"    },
    { key: "amber",   label: "Amber"   },
    { key: "teal",    label: "Teal"    },
  ];

  let openCard = null;

  function persist(model) {
    if (typeof I.updateSticky === "function") I.updateSticky(model);
    else if (typeof I.UPDATE === "function") I.UPDATE(model);
    else if (typeof I.STORE === "function") I.STORE(model);
  }

  function closePalette() {
    if (!openCard) return;
    openCard.classList.remove("sticky_paletteOpen");
    openCard = null;
  }

  document.addEventListener("pointerdown", (e) => {
    if (!openCard) return;
    if (openCard.contains(e.target)) return;
    closePalette();
  }, true);

  function ensurePalette(cardEl, model) {
    if (!cardEl || cardEl.querySelector(".sticky_color")) return;

    const init = String(model?.color || "emerald");
    cardEl.setAttribute("data-sticky-color", init);

    const closeBtn = cardEl.querySelector(".sticky_close");
    if (!closeBtn) return;

    const colorBtn = document.createElement("button");
    colorBtn.type = "button";
    colorBtn.className = "sticky_color";
    colorBtn.setAttribute("aria-label", "color");
    colorBtn.textContent = "🎨";

    const palette = document.createElement("div");
    palette.className = "sticky_palette";
    palette.setAttribute("aria-hidden", "true");

    const inner = document.createElement("div");
    inner.className = "sticky_paletteInner";

    COLORS.forEach((c) => {
      const sw = document.createElement("button");
      sw.type = "button";
      sw.className = "sticky_swatch";
      sw.setAttribute("data-color", c.key);
      sw.setAttribute("aria-label", c.label);

      sw.addEventListener("click", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();

        model.color = c.key;
        cardEl.setAttribute("data-sticky-color", c.key);

        persist(model);
        closePalette();
      });

      inner.appendChild(sw);
    });

    palette.appendChild(inner);

    closeBtn.insertAdjacentElement("afterend", colorBtn);
    cardEl.appendChild(palette);

    colorBtn.addEventListener("click", (ev) => {
      ev.preventDefault();
      ev.stopPropagation();

      if (openCard && openCard !== cardEl) openCard.classList.remove("sticky_paletteOpen");
      const isOpen = cardEl.classList.toggle("sticky_paletteOpen");
      openCard = isOpen ? cardEl : null;
    });
  }

  const _toast = I.buildToastCard;
  const _float = I.buildFloatingCard;

  I.buildToastCard = (m) => {
    const c = _toast(m);
    ensurePalette(c, m);
    return c;
  };

  I.buildFloatingCard = (m) => {
    const c = _float(m);
    ensurePalette(c, m);
    return c;
  };
})();