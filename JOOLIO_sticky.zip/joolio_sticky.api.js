(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  if (I.__apiInstalled) return;
  I.__apiInstalled = true;

  api.create = (payload) => {
    const model = I.createModel(payload);
    if (!model) return null;

    if (!model.__seq) model.__seq = ++I.cardSeq;
    I.upsertModel(model);

    if (model.state === "pinned") {
      I.renderPinnedBar && I.renderPinnedBar();
      return model.sticky_id;
    }

    if (model.state === "floating") {
      // ✅ حتی اگر backend x/y داده، یک spawn-slot رزرو می‌کنیم تا restore روی هم نیفتد
      I.reserveSpawnSlot && I.reserveSpawnSlot();

      if (!Number.isFinite(model.x) || !Number.isFinite(model.y)) {
        const xy = I.nextFloatingSpawnXY();
        model.x = xy.x;
        model.y = xy.y;
      }

      const card = I.buildFloatingCard(model);
      I.floating.appendChild(card);
      return model.sticky_id;
    }

    // toast
    const card = I.buildToastCard(model);
    I.toasts.prepend(card);
    return model.sticky_id;
  };

  api.createMany = (arr) => {
    const list = Array.isArray(arr) ? arr : [];
    for (let i = list.length - 1; i >= 0; i--) api.create(list[i]);
    I.renderPinnedBar && I.renderPinnedBar();
  };

  api.clearAll = () => {
    I.toasts.innerHTML = "";
    I.floating.innerHTML = "";
    I.pinnedBar.innerHTML = "";
    I.models = [];
    I.cardSeq = 0;
    I.__spawnIndex = 0;
  };

  api.setCallbacks = ({ update_sticky, store_sticky, delete_sticky, reply_sticky } = {}) => {
    I.UPDATE = (typeof update_sticky === "function") ? update_sticky
            : (typeof store_sticky === "function") ? store_sticky
            : null;

    I.DELETE = (typeof delete_sticky === "function") ? delete_sticky : null;
    I.REPLY  = (typeof reply_sticky === "function") ? reply_sticky : null;
  };

  api.setCrmHeaderId = (id) => { I.crmHeaderId = String(id || ""); };
  api.setLang = (lang) => { I.lang = String(lang || ""); };
})();