(() => {
  const api = window.JOOLIOSticky;
  if (!api?.__internal) return;

  api.__internal.attachDebugBadge = (cardEl, seq) => {
    const badge = document.createElement("div");
    badge.className = "sticky_debugSeq";
    badge.textContent = String(seq);
    cardEl.appendChild(badge);
    cardEl.dataset.seq = String(seq);
  };
})();

