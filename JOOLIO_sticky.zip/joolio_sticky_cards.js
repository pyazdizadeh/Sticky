(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  I.buildToastCard = (model) => {
    const c = document.createElement("div");
    c.className = "sticky_card";
    c.dataset.id = model.id;

    c.innerHTML = `
      <button class="sticky_close" type="button" aria-label="close">×</button>
      <button class="sticky_pin" type="button" aria-label="pin">📌</button>

      <div class="sticky_message">${I.sanitize(model.message)}</div>

      <div class="sticky_reply">
        <input class="sticky_replyInput" type="text" placeholder="${I.sanitize(I.t("reply_placeholder"))}" />
        <button class="sticky_send" type="button" aria-label="send">➤</button>
      </div>
    `;

    I.attachDebugBadge && I.attachDebugBadge(c, model.__seq);

    const closeBtn = c.querySelector(".sticky_close");
    const pinBtn = c.querySelector(".sticky_pin");
    const input = c.querySelector(".sticky_replyInput");
    const sendBtn = c.querySelector(".sticky_send");

    closeBtn.addEventListener("click", () => {
      const sp = I.makeSpacerFromCard(c, model.id);
      c.replaceWith(sp);
      if (typeof I.DELETE === "function") I.DELETE({ id: model.id });
    });

    pinBtn.addEventListener("click", () => {
      const rect = c.getBoundingClientRect();
      model.x = Math.round(rect.left);
      model.y = Math.round(rect.top);

      const sp = I.makeSpacerFromCard(c, model.id);
      c.replaceWith(sp);

      I.createPinnedTab(model);

      if (typeof I.STORE === "function") I.STORE({ id: model.id, state: "pinned", x: model.x, y: model.y });
    });

    sendBtn.addEventListener("click", () => {
      const text = I.sanitize(input.value);
      if (!text) return;
      input.value = "";
      if (typeof I.REPLY === "function") I.REPLY({ id: model.id, text });
    });

    return c;
  };

  I.buildFloatingCard = (model) => {
    const c = document.createElement("div");
    c.className = "sticky_card";
    c.dataset.id = model.id;

    c.style.position = "fixed";
    c.style.left = (Number.isFinite(model.x) ? model.x : 16) + "px";
    c.style.top  = (Number.isFinite(model.y) ? model.y : 96) + "px";
    c.style.zIndex = String(++I.floatingZ);

    c.innerHTML = `
      <button class="sticky_close" type="button" aria-label="close">×</button>
      <button class="sticky_pin" type="button" aria-label="pin">📌</button>

      <div class="sticky_message">${I.sanitize(model.message)}</div>

      <div class="sticky_reply">
        <input class="sticky_replyInput" type="text" placeholder="${I.sanitize(I.t("reply_placeholder"))}" />
        <button class="sticky_send" type="button" aria-label="send">➤</button>
      </div>
    `;

    I.attachDebugBadge && I.attachDebugBadge(c, model.__seq);

    const closeBtn = c.querySelector(".sticky_close");
    const pinBtn = c.querySelector(".sticky_pin");
    const input = c.querySelector(".sticky_replyInput");
    const sendBtn = c.querySelector(".sticky_send");

    closeBtn.addEventListener("click", () => {
      c.remove();
      if (typeof I.DELETE === "function") I.DELETE({ id: model.id });
    });

    pinBtn.addEventListener("click", () => {
      const rect = c.getBoundingClientRect();
      model.x = Math.round(rect.left);
      model.y = Math.round(rect.top);

      c.remove();
      I.createPinnedTab(model);

      if (typeof I.STORE === "function") I.STORE({ id: model.id, state: "pinned", x: model.x, y: model.y });
    });

    sendBtn.addEventListener("click", () => {
      const text = I.sanitize(input.value);
      if (!text) return;
      input.value = "";
      if (typeof I.REPLY === "function") I.REPLY({ id: model.id, text });
    });

    I.enableDragFloating && I.enableDragFloating(c, model);

    return c;
  };
})();

