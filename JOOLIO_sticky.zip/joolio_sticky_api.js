(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  api.create = (payload) => {
    const base = I.createModel(payload);
    const model = { ...base, __seq: ++I.cardSeq };

    const card = I.buildToastCard(model);

    // ✅ FIX: new card appears ABOVE existing ones (debug-friendly)
    I.toasts.prepend(card);

    return model.id;
  };

  api.createMany = (arr) => {
    (Array.isArray(arr) ? arr : []).forEach(api.create);
  };

  api.clearAll = () => {
    I.toasts.innerHTML = "";
    I.floating.innerHTML = "";
    I.pinnedBar.innerHTML = "";
  };

  api.setCallbacks = ({ store_sticky, delete_sticky, reply_sticky } = {}) => {
    I.STORE = (typeof store_sticky === "function") ? store_sticky : null;
    I.DELETE = (typeof delete_sticky === "function") ? delete_sticky : null;
    I.REPLY = (typeof reply_sticky === "function") ? reply_sticky : null;
  };

  api.setCrmHeaderId = (id) => {
    I.root.setAttribute("data-crm-header", String(id || ""));
  };

  api.setLang = (lang) => {
    I.root.setAttribute("data-lang", String(lang || ""));
  };
})();

