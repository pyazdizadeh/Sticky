(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  function wireReply(cardEl, model){
    const input = cardEl.querySelector(".sticky_replyInput");
    const sendBtn = cardEl.querySelector(".sticky_send");
    if (!input || !sendBtn) return;

    sendBtn.addEventListener("click", () => {
      const text = I.sanitize(input.value);
      if (!text) return;
      input.value = "";
      if (typeof I.REPLY === "function") {
        I.REPLY({ id: model.id, sticky_id: model.sticky_id, text });
      }
    });
  }

  function baseInner(model){
    return `
      <button class="sticky_close" type="button" aria-label="close">×</button>
      <button class="sticky_pin" type="button" aria-label="pin">📌</button>

      <div class="sticky_message">${I.sanitize(model.message)}</div>

      <div class="sticky_reply">
        <input class="sticky_replyInput" type="text" placeholder="${I.sanitize(I.t("reply_placeholder"))}" />
        <button class="sticky_send" type="button" aria-label="send">➤</button>
      </div>
    `;
  }

  /* ---------- TOAST ---------- */
  I.buildToastCard = (model) => {
    const c = document.createElement("div");
    c.className = "sticky_card";
    c.dataset.id = model.id;
    c.innerHTML = baseInner(model);

    const closeBtn = c.querySelector(".sticky_close");
    const pinBtn = c.querySelector(".sticky_pin");

    closeBtn.addEventListener("click", () => {
      const sp = I.makeSpacerFromCard(c, model.id);
      c.replaceWith(sp);
      if (typeof I.DELETE === "function") I.DELETE({ id: model.id, sticky_id: model.sticky_id });
    });

    pinBtn.addEventListener("click", () => {
      const r = c.getBoundingClientRect();
      model.x = Math.round(r.left);
      model.y = Math.round(r.top);

      const sp = I.makeSpacerFromCard(c, model.id);
      c.replaceWith(sp);

      model.state = "pinned";
      I.createPinnedTab(model);

      if (typeof I.UPDATE === "function") I.UPDATE(model);
    });

    wireReply(c, model);
    return c;
  };

  /* ---------- FLOATING ---------- */
  I.buildFloatingCard = (model) => {
    const c = document.createElement("div");
    c.className = "sticky_card";
    c.dataset.id = model.id;

    c.style.position = "fixed";
    c.style.left = (Number.isFinite(model.x) ? model.x : 16) + "px";
    c.style.top  = (Number.isFinite(model.y) ? model.y : 96) + "px";
    c.style.zIndex = String(++I.floatingZ);

    c.innerHTML = baseInner(model);

    const closeBtn = c.querySelector(".sticky_close");
    const pinBtn = c.querySelector(".sticky_pin");

    closeBtn.addEventListener("click", () => {
      c.remove();
      if (typeof I.DELETE === "function") I.DELETE({ id: model.id, sticky_id: model.sticky_id });
    });

    pinBtn.addEventListener("click", () => {
      const r = c.getBoundingClientRect();
      model.x = Math.round(r.left);
      model.y = Math.round(r.top);

      c.remove();

      model.state = "pinned";
      I.createPinnedTab(model);

      if (typeof I.UPDATE === "function") I.UPDATE(model);
    });

    wireReply(c, model);
    return c;
  };
})();