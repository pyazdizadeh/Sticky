(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  I.enableDragFloating = (cardEl, model) => {
    let dragging = false;
    let pid = null;
    let startX = 0, startY = 0;
    let originL = 0, originT = 0;

    const shouldIgnoreStart = (target) => {
      if (!target) return false;
      if (target.closest(".sticky_close")) return true;
      if (target.closest(".sticky_pin")) return true;
      if (target.closest(".sticky_color")) return true;
      if (target.closest(".sticky_send")) return true;
      if (target.closest(".sticky_replyInput")) return true;
      if (target.closest(".sticky_todoWrap")) return true;
      return false;
    };

    const onDown = (e) => {
      if (shouldIgnoreStart(e.target)) return;
      if (e.button !== undefined && e.button !== 0) return;

      dragging = true;
      pid = e.pointerId;

      const rect = cardEl.getBoundingClientRect();
      originL = rect.left;
      originT = rect.top;

      startX = e.clientX;
      startY = e.clientY;

      cardEl.style.zIndex = String(++I.floatingZ);

      try { cardEl.setPointerCapture(pid); } catch(_) {}
      e.preventDefault();
    };

    const onMove = (e) => {
      if (!dragging) return;
      if (pid !== null && e.pointerId !== pid) return;

      const dx = e.clientX - startX;
      const dy = e.clientY - startY;

      const nextL = Math.round(originL + dx);
      const nextT = Math.round(originT + dy);

      cardEl.style.left = nextL + "px";
      cardEl.style.top = nextT + "px";

      model.x = nextL;
      model.y = nextT;

      e.preventDefault();
    };

    const onUp = (e) => {
      if (!dragging) return;
      if (pid !== null && e.pointerId !== pid) return;

      dragging = false;

      try { cardEl.releasePointerCapture(pid); } catch(_) {}
      pid = null;

      model.state = "floating";

      // ✅ استاندارد: مدل کامل را به update بده
      if (typeof I.UPDATE === "function") I.UPDATE(model);
    };

    cardEl.addEventListener("pointerdown", onDown, { passive: false });
    cardEl.addEventListener("pointermove", onMove, { passive: false });
    cardEl.addEventListener("pointerup", onUp);
    cardEl.addEventListener("pointercancel", onUp);
  };
})();