(() => {
  const root = document.getElementById("sticky_root");
  if (!root) return;

  const toasts = document.getElementById("sticky_toasts");
  const floating = document.getElementById("sticky_floating");
  const pinnedBar = document.getElementById("sticky_pinnedBar");

  let STORE = null, DELETE = null, REPLY = null;

  let floatingZ = 9100;

  // DEBUG: incremental card number
  let cardSeq = 0;

  const t = (k) => (root.__sticky_t__ ? root.__sticky_t__(k) : k);

  const sanitize = (s) =>
    String(s || "")
      .replace(/[<>`"'&]/g, "")
      .replace(/\s+/g, " ")
      .trim();

  function createModel(payload){
    return {
      id: String(payload?.sticky_id || payload?.id || Date.now()),
      message: String(payload?.message || ""),
      x: Number.isFinite(payload?.x) ? payload.x : null,
      y: Number.isFinite(payload?.y) ? payload.y : null
    };
  }

  /* =========================
     Spacer — RESERVED slot per id
  ========================= */
  function makeSpacerFromCard(cardEl, id){
    const r = cardEl.getBoundingClientRect();
    const sp = document.createElement("div");
    sp.className = "sticky_spacer";
    sp.style.height = Math.max(0, Math.round(r.height)) + "px";
    sp.dataset.spacer = "1";
    sp.dataset.id = String(id || "");
    return sp;
  }

  function removeSpacerById(id){
    const safeId = String(id || "");
    // Avoid CSS.escape dependency for older webviews:
    const all = toasts.querySelectorAll('.sticky_spacer[data-spacer="1"]');
    for (let i = 0; i < all.length; i++){
      if (all[i].dataset.id === safeId) {
        all[i].remove();
        return;
      }
    }
  }

  /* =========================
     DEBUG Badge (visual numbering)
  ========================= */
  function attachDebugBadge(cardEl, seq){
    const badge = document.createElement("div");
    badge.className = "sticky_debugSeq";
    badge.textContent = String(seq);
    cardEl.appendChild(badge);

    // also helpful for inspecting in devtools:
    cardEl.dataset.seq = String(seq);
  }

  /* =========================
     DRAG (Mobile-safe) — ONLY for floating cards
  ========================= */
  function enableDragFloating(cardEl, model){
    let dragging = false;
    let pid = null;
    let startX = 0, startY = 0;
    let originL = 0, originT = 0;

    const shouldIgnoreStart = (target) => {
      if (!target) return false;
      if (target.closest(".sticky_close")) return true;
      if (target.closest(".sticky_pin")) return true;
      if (target.closest(".sticky_send")) return true;
      if (target.closest(".sticky_replyInput")) return true;
      return false;
    };

    const onDown = (e) => {
      if (shouldIgnoreStart(e.target)) return;
      if (e.button !== undefined && e.button !== 0) return;

      dragging = true;
      pid = e.pointerId;

      const rect = cardEl.getBoundingClientRect();
      originL = rect.left;
      originT = rect.top;

      startX = e.clientX;
      startY = e.clientY;

      cardEl.style.zIndex = String(++floatingZ);

      try { cardEl.setPointerCapture(pid); } catch(_) {}
      e.preventDefault();
    };

    const onMove = (e) => {
      if (!dragging) return;
      if (pid !== null && e.pointerId !== pid) return;

      const dx = e.clientX - startX;
      const dy = e.clientY - startY;

      const nextL = Math.round(originL + dx);
      const nextT = Math.round(originT + dy);

      cardEl.style.left = nextL + "px";
      cardEl.style.top = nextT + "px";

      model.x = nextL;
      model.y = nextT;

      e.preventDefault();
    };

    const onUp = (e) => {
      if (!dragging) return;
      if (pid !== null && e.pointerId !== pid) return;

      dragging = false;

      try { cardEl.releasePointerCapture(pid); } catch(_) {}
      pid = null;

      if (typeof STORE === "function") {
        STORE({ id: model.id, x: model.x, y: model.y, state: "floating" });
      }
    };

    cardEl.addEventListener("pointerdown", onDown, { passive: false });
    cardEl.addEventListener("pointermove", onMove, { passive: false });
    cardEl.addEventListener("pointerup", onUp);
    cardEl.addEventListener("pointercancel", onUp);
  }

  /* ---------- Toast Card (NOT fixed; stacks in flex) ---------- */
  function buildToastCard(model){
    const c = document.createElement("div");
    c.className = "sticky_card";
    c.dataset.id = model.id;

    c.innerHTML = `
      <button class="sticky_close" type="button" aria-label="close">×</button>
      <button class="sticky_pin" type="button" aria-label="pin">📌</button>

      <div class="sticky_message">${sanitize(model.message)}</div>

      <div class="sticky_reply">
        <input class="sticky_replyInput" type="text" placeholder="${sanitize(t("reply_placeholder"))}" />
        <button class="sticky_send" type="button" aria-label="send">➤</button>
      </div>
    `;

    // DEBUG
    attachDebugBadge(c, model.__seq);

    const closeBtn = c.querySelector(".sticky_close");
    const pinBtn = c.querySelector(".sticky_pin");
    const input = c.querySelector(".sticky_replyInput");
    const sendBtn = c.querySelector(".sticky_send");

    closeBtn.addEventListener("click", () => {
      const sp = makeSpacerFromCard(c, model.id);
      c.replaceWith(sp);
      if (typeof DELETE === "function") DELETE({ id: model.id });
      // reserved spacer stays
    });

    pinBtn.addEventListener("click", () => {
      const rect = c.getBoundingClientRect();
      model.x = Math.round(rect.left);
      model.y = Math.round(rect.top);

      const sp = makeSpacerFromCard(c, model.id);
      c.replaceWith(sp);

      createPinnedTab(model);

      if (typeof STORE === "function") STORE({ id: model.id, state: "pinned", x: model.x, y: model.y });
    });

    sendBtn.addEventListener("click", () => {
      const text = sanitize(input.value);
      if (!text) return;
      input.value = "";
      if (typeof REPLY === "function") REPLY({ id: model.id, text });
    });

    return c;
  }

  /* ---------- Floating Card (fixed; restores to saved x,y + draggable) ---------- */
  function buildFloatingCard(model){
    const c = document.createElement("div");
    c.className = "sticky_card";
    c.dataset.id = model.id;

    c.style.position = "fixed";
    c.style.left = (Number.isFinite(model.x) ? model.x : 16) + "px";
    c.style.top  = (Number.isFinite(model.y) ? model.y : 96) + "px";
    c.style.zIndex = String(++floatingZ);

    c.innerHTML = `
      <button class="sticky_close" type="button" aria-label="close">×</button>
      <button class="sticky_pin" type="button" aria-label="pin">📌</button>

      <div class="sticky_message">${sanitize(model.message)}</div>

      <div class="sticky_reply">
        <input class="sticky_replyInput" type="text" placeholder="${sanitize(t("reply_placeholder"))}" />
        <button class="sticky_send" type="button" aria-label="send">➤</button>
      </div>
    `;

    // DEBUG
    attachDebugBadge(c, model.__seq);

    const closeBtn = c.querySelector(".sticky_close");
    const pinBtn = c.querySelector(".sticky_pin");
    const input = c.querySelector(".sticky_replyInput");
    const sendBtn = c.querySelector(".sticky_send");

    closeBtn.addEventListener("click", () => {
      c.remove();
      if (typeof DELETE === "function") DELETE({ id: model.id });
    });

    pinBtn.addEventListener("click", () => {
      const rect = c.getBoundingClientRect();
      model.x = Math.round(rect.left);
      model.y = Math.round(rect.top);

      c.remove();
      createPinnedTab(model);

      if (typeof STORE === "function") STORE({ id: model.id, state: "pinned", x: model.x, y: model.y });
    });

    sendBtn.addEventListener("click", () => {
      const text = sanitize(input.value);
      if (!text) return;
      input.value = "";
      if (typeof REPLY === "function") REPLY({ id: model.id, text });
    });

    // enable drag (floating only)
    enableDragFloating(c, model);

    return c;
  }

  /* ---------- Pinned Tab ---------- */
  function createPinnedTab(model){
    const tab = document.createElement("div");
    tab.className = "sticky_pinnedTab";
    tab.dataset.id = model.id;
    tab.dataset.seq = String(model.__seq || "");

    const titleBase = (model.message || t("pinned_fallback") || "Sticky").slice(0, 22);
    const title = `#${model.__seq} • ${titleBase}`;
    tab.innerHTML = `<div class="sticky_pinnedTabTitle">${sanitize(title)}</div>`;

    tab.addEventListener("click", () => {
      const card = buildFloatingCard(model);
      floating.appendChild(card);
      tab.remove();

      // remove reserved slot for this id
      removeSpacerById(model.id);
    });

    pinnedBar.appendChild(tab);
  }

  /* ---------- Public API ---------- */
  function create(payload){
    const base = createModel(payload);

    // DEBUG assign sequence per created card
    const model = { ...base, __seq: ++cardSeq };

    const card = buildToastCard(model);

    // IMPORTANT: new cards never replace spacers
    toasts.appendChild(card);

    return model.id;
  }

  function createMany(arr){
    (Array.isArray(arr) ? arr : []).forEach(create);
  }

  function clearAll(){
    toasts.innerHTML = "";
    floating.innerHTML = "";
    pinnedBar.innerHTML = "";
  }

  function setCallbacks({ store_sticky, delete_sticky, reply_sticky } = {}){
    STORE = (typeof store_sticky === "function") ? store_sticky : null;
    DELETE = (typeof delete_sticky === "function") ? delete_sticky : null;
    REPLY = (typeof reply_sticky === "function") ? reply_sticky : null;
  }

  function setCrmHeaderId(id){
    root.setAttribute("data-crm-header", String(id || ""));
  }

  function setLang(lang){
    root.setAttribute("data-lang", String(lang || ""));
  }

  window.JOOLIOSticky = { create, createMany, clearAll, setCallbacks, setCrmHeaderId, setLang };
})();