# JOOLIO Sticky Cards Project - Instructions for AI Agent

You are working on the JOOLIO Sticky Cards project, a sticky card management system for CRM written in vanilla JavaScript. This project includes toast cards, floating cards, pinned cards, TODO management, chat/thread system, sharing system, color system, and auto-hide functionality.

## Project Files Structure

The project contains 20 files:

**HTML:**
- `index.html` - Main test page with two test buttons

**JavaScript (12 files):**
1. `joolio_i18n.js` - Internationalization
2. `joolio_sticky_language.js` - Language settings
3. `joolio_sticky_core.js` - Core system
4. `joolio_sticky_toast_layout.js` - Toast layout
5. `joolio_sticky_spacer_pinned.js` - Pinned cards spacer
6. `joolio_sticky_drag.js` - Drag & drop
7. `joolio_sticky_cards.js` - Card creation and management
8. `joolio_sticky_color.js` - Color picker
9. `joolio_sticky_api.js` - Public API
10. `joolio_sticky_todo.js` - TODO management
11. `joolio_sticky_autohide.js` - Auto-hide system
12. `joolio_sticky_share.js` - Card sharing system

**CSS (4 files):**
1. `joolio_sticky.css` - Main styles
2. `joolio_sticky_ltr.css` - LTR styles
3. `joolio_sticky_js.css` - Styles extracted from inline JS (NEW)
4. `patch.css` - Additional settings

**Documentation:**
- `README.md` - Complete guide

## CRITICAL RULES - MUST FOLLOW

### Rule 1: NO INLINE STYLES - STRICTLY FORBIDDEN

**NEVER use inline styles in JavaScript files. This is the most important rule.**

❌ **WRONG:**
```javascript
element.style.cssText = 'padding: 10px; color: red;';
element.style.backgroundColor = 'blue';
```

✅ **CORRECT:**
```javascript
element.className = 'sticky_myElement';
// Then add to joolio_sticky_js.css:
// .sticky_myElement { padding: 10px; color: red; }
```

**Requirements:**
- Every element must receive a proper `className`
- All styles must be defined in CSS files
- Classes must be isolated and conflict-free
- Use CSS classes for states (`:hover`, `.sticky_selected`)

### Rule 2: Thread Messages - Fixed Layout independent of RTL or LTR

**FIXED RULE - Never changes with RTL/LTR:**

**Current user messages:**
- Always right-aligned (`flex-direction: row-reverse`)
- Blue metallic gradient color
- Avatar on the right side
- Detection: `message.username === model.username`

**Other users' messages:**
- Always left-aligned (`flex-direction: row`)
- Color matches card (`data-sticky-color`)
- Avatar on the left side

**Implementation:**
```javascript
// Detect current user
const currentUser = model?.username || '';
const messageUser = message?.username || '';
const isSelf = currentUser && messageUser === currentUser;

// Add class
const selfClass = isSelf ? ' sticky_threadSelf' : '';
```

**Required CSS:**
```css
/* This rule is FIXED and doesn't change with RTL/LTR */
.sticky_threadMsg.sticky_threadSelf {
  flex-direction: row-reverse !important;
  margin-left: auto !important;
  margin-right: 0 !important;
}

.sticky_threadMsg:not(.sticky_threadSelf) {
  flex-direction: row !important;
  margin-right: auto !important;
  margin-left: 0 !important;
}
```

### Rule 3: Share Modal - Exact 6-Segment Structure

**MUST follow this exact order:**

1. **Header**: Title "کاربران مشارکت کننده" (Participating Users) + Close button
2. **Shared Users Table**: 4 columns:
   - Counter (#)
   - Name (user_full_name)
   - Role (مدیر/Moderator or کاربر/User)
   - Actions (Exit button - only for non-moderators)
3. **HR**: Separator line
4. **Search Input**: Search users (moderator only)
5. **HR**: Separator line
6. **Submit Button**: Invite button (moderator only)

**Access Rules:**

**Moderator** (`is_moderator = true`):
- Can remove users (except themselves)
- Can add new users
- Has access to search and submit button

**Regular User:**
- Can only view the list
- Cannot add or remove users

**Remove User Operation Order:**
```javascript
// 1. Call callback FIRST
if (typeof I.REMOVE_SHARED_USER === 'function') {
  I.REMOVE_SHARED_USER({
    sticky_id: model.sticky_id,
    username: user.username
  });
}

// 2. Remove from array
const index = model.shared_with.findIndex(u => u.username === user.username);
if (index !== -1) {
  model.shared_with.splice(index, 1);
}

// 3. Remove from UI
tr.remove();
```

### Rule 4: Delete Confirmation Modal

**Display Conditions:**
- Only show when `model.shared_with.length > 1`
- Meaning: card is shared with other users (besides moderator)

**Styling:**
- Must match the card exactly:
```javascript
modal.className = 'sticky_shareModal sticky_card sticky_confirmModal';
modal.setAttribute('data-sticky-color', model.color);
modal.setAttribute('data-sticky-state', model.state);
```

### Rule 5: Payload Structures - STRICTLY ENFORCE

**TODO Structure (REQUIRED):**
```javascript
{
  tid: string,           // Unique ID
  text: string,          // TODO text
  done: boolean,         // Completion status
  children: [            // Sub-items
    {
      tid: string,
      text: string,
      done: boolean
    }
  ]
}
```

**Thread Structure:**
```javascript
{
  reply: [                      // OR model.thread as direct array
    {
      thread_order: number,     // Order
      username: string,         // Username
      user_full_name: string,   // Full name
      text: string,             // Message text
      created_at: string        // Creation time
    }
  ]
}
```

**Shared Users Structure:**
```javascript
[
  {
    username: string,           // Username
    user_full_name: string,     // Full name
    shared_order: number,       // Order (first = moderator)
    shared_at: string          // Share time
  }
]
```

### Rule 6: Callbacks Naming Convention

**In HTML:**
```javascript
JOOLIOSticky.setCallbacks({
  store_sticky: (payload) => {},
  delete_sticky: (payload) => {},
  reply_sticky: (payload) => {},
  archive_sticky: (payload) => {},
  share_sticky: (payload) => {},
  remove_shared_user: (payload) => {},
  search_users: ({ query }) => {}
});
```

**In JS (with I. prefix):**
```javascript
if (typeof I.STORE === 'function') I.STORE(model);
if (typeof I.DELETE === 'function') I.DELETE({ sticky_id: model.sticky_id });
if (typeof I.SHARE === 'function') I.SHARE({ sticky_id, username });
```

**Mapping in api.js:**
```javascript
I.STORE = store_sticky;
I.DELETE = delete_sticky;
I.REPLY = reply_sticky;
I.ARCHIVE = archive_sticky;
I.SHARE = share_sticky;
I.REMOVE_SHARED_USER = remove_shared_user;
I.SEARCH_USERS = search_users;
```

### Rule 7: CSS Class Naming

**Required Prefix:**
- All classes MUST start with `sticky_`
- Example: `.sticky_card`, `.sticky_shareModal`, `.sticky_threadMsg`

**BEM-like Convention:**
- Block: `.sticky_card`
- Element: `.sticky_card_header`
- Modifier: `.sticky_card--floating`
- State: `.sticky_card.sticky_selected`

**Isolation:**
- Use `!important` for fixed rules (like thread direction)
- Use CSS specificity to prevent conflicts
- Each feature in separate file (e.g., `joolio_sticky_js.css`)

### Rule 8: Segments

**Segments in Payload:**
```javascript
segments: {
  header: boolean,        // Card header
  html_segment: boolean,  // HTML content
  todo: boolean,          // TODO list
  thread: boolean,        // Message display
  reply: boolean          // Reply form
}
```

**Check in JS:**
```javascript
if (model.segments?.todo) {
  // render TODO section
}

if (model.segments?.thread) {
  // render thread messages
}
```

## Known Issues You Should Be Aware Of

### ⚠️ TODO Module Not Connected

**Status**: TODO module exists but is not connected to cards.js
**Problem**: `segments.todo` exists in payload but is not checked
**Needs**: Connection to renderCard in cards.js

**Suggested Solution:**
```javascript
// In joolio_sticky_cards.js
function renderCard(model) {
  // ... existing code ...
  
  // Add TODO section
  if (model.segments?.todo) {
    const todoContainer = document.createElement('div');
    todoContainer.className = 'sticky_todoWrap';
    cardElement.appendChild(todoContainer);
    
    // Call render from todo.js
    if (typeof I.renderTodo === 'function') {
      I.renderTodo(todoContainer, model);
    }
  }
}
```

### ⚠️ Thread Structure - Two Access Methods

**Both supported**: `model.thread` (array) OR `model.thread.reply` (object)
**Solution**: getThreadItems supports both methods

## Complete Usage Example

**HTML Setup:**
```html
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <link rel="stylesheet" href="joolio_sticky.css">
  <link rel="stylesheet" href="joolio_sticky_js.css">
  <link rel="stylesheet" href="patch.css">
</head>
<body>
  <div id="sticky_root" class="sticky_root" dir="rtl"></div>
  
  <!-- JS loading order is important -->
  <script src="joolio_i18n.js"></script>
  <script src="joolio_sticky_language.js"></script>
  <script src="joolio_sticky_core.js"></script>
  <script src="joolio_sticky_toast_layout.js"></script>
  <script src="joolio_sticky_spacer_pinned.js"></script>
  <script src="joolio_sticky_drag.js"></script>
  <script src="joolio_sticky_cards.js"></script>
  <script src="joolio_sticky_color.js"></script>
  <script src="joolio_sticky_api.js"></script>
  <script src="joolio_sticky_todo.js"></script>
  <script src="joolio_sticky_autohide.js"></script>
  <script src="joolio_sticky_share.js"></script>
</body>
</html>
```

**JavaScript Setup:**
```javascript
// Setup callbacks
JOOLIOSticky.setCallbacks({
  store_sticky: (payload) => {
    console.log('Store card:', payload);
    // Save to backend
  },
  delete_sticky: ({ sticky_id }) => {
    console.log('Delete card:', sticky_id);
    // Delete from backend
  },
  share_sticky: ({ sticky_id, username }) => {
    console.log('Share with:', username);
    // Share in backend
  },
  remove_shared_user: ({ sticky_id, username }) => {
    console.log('Remove user:', username);
    // Remove from backend
  },
  search_users: ({ query }) => {
    // Search in backend and return array
    return [
      { username: 'user1', name: 'User One' },
      { username: 'user2', name: 'User Two' }
    ];
  }
});

// Create card
JOOLIOSticky.create({
  sticky_id: 'card-123',
  is_moderator: true,
  color: 'green',
  from_user: {
    username: 'admin',
    user_full_name: 'System Admin'
  },
  html_segment: '<div>Card content</div>',
  todos: [
    {
      tid: 'todo1',
      text: 'First task',
      done: false,
      children: []
    }
  ],
  thread: {
    reply: [
      {
        thread_order: 1,
        username: 'user1',
        user_full_name: 'User One',
        text: 'Hello',
        created_at: '10:00'
      }
    ]
  },
  shared_with: [
    {
      username: 'admin',
      user_full_name: 'Admin',
      shared_order: 1,
      shared_at: '09:00'
    }
  ],
  position: { x: 100, y: 100, width: 360, height: 400 },
  segments: {
    header: true,
    html_segment: true,
    todo: true,
    thread: true,
    reply: true
  }
});
```

## Important Code References

**Detect current user in thread:**
```javascript
const currentUser = model?.from_user?.username;
const isSelf = message?.username === currentUser;
```

**Check moderator:**
```javascript
const isModerator = model?.is_moderator || model?.is_admin;
```

**Check if card is shared:**
```javascript
const hasShares = model?.shared_with?.length > 1;
```

**Get thread items (supports both structures):**
```javascript
const items = Array.isArray(model?.thread?.reply) 
  ? model.thread.reply 
  : (Array.isArray(model?.thread) ? model.thread : []);
```

## Checklist Before Any Change

When making changes, verify:

- [ ] Am I using inline styles? (MUST be ❌)
- [ ] Did I add className? (MUST be ✅)
- [ ] Did I add CSS to `joolio_sticky_js.css`? (MUST be ✅)
- [ ] Is thread current user styling correct? (Right-aligned + blue)
- [ ] Does share modal have 6 segments in correct order?
- [ ] Are callbacks called in correct order?
- [ ] Is payload structure correct?
- [ ] Do all classes start with `sticky_` prefix?

## Quick Reference

**File to modify for:**
- Share modal styles → `joolio_sticky_js.css`
- Card styles → `joolio_sticky.css`
- RTL/LTR styles → `joolio_sticky_ltr.css`
- Thread logic → `joolio_sticky_cards.js`
- Share logic → `joolio_sticky_share.js`
- TODO logic → `joolio_sticky_todo.js`

**Key files to read:**
- `README.md` - Complete project guide
- `CONFLICT_REPORT.txt` - All conflicts and resolutions
- `index.html` - Payload examples and usage

## Your Task

When given a task:

1. **First**, read the relevant files from the project
2. **Check** which rule applies to your task
3. **Never** use inline styles - always use className + CSS
4. **Follow** the exact structure for share modal (6 segments)
5. **Remember** thread current user is always right-aligned
6. **Verify** your changes against the checklist above
7. **Test** that callbacks are called in correct order

## Testing Commands

```bash
# Extract ZIP
unzip joolio_sticky_final.zip

# Open in browser
open index.html

# Check console for errors
# F12 → Console

# Test cards
# Click "تست کامل" (Complete Test) or "تست TODO" (TODO Test)
```

## Final Reminders

1. **NEVER use inline styles** - This is rule #1
2. **Thread direction is FIXED** - Current user always right-aligned (independent of RTL/LTR)
3. **Share modal MUST have 6 segments** - Order matters
4. **Callbacks have order** - First callback, then model update, then UI
5. **TODO module is separate** - Needs connection to cards
6. **CSS classes MUST have prefix** - Always `sticky_`
7. **All classes are isolated** - No conflicts
8. **Read CONFLICT_REPORT.txt** - All conflicts are resolved

---

**Date**: 2026-01-31
**Version**: 1.0
**Status**: Production Ready (except TODO module needs connection)

You now have all the knowledge needed to continue this project. Follow these rules strictly, especially NO INLINE STYLES. Good luck! 🚀
