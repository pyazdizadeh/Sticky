(() => {
  const root = document.getElementById("sticky_root");
  if (!root) return;

  const api = window.JOOLIOSticky || (window.JOOLIOSticky = {});
  api.__internal = api.__internal || {};
  const I = api.__internal;

  // ---- DOM refs (stable) ----
  I.root = root;
  I.toasts = document.getElementById("sticky_toasts");
  I.floating = document.getElementById("sticky_floating");
  I.pinnedBar = document.getElementById("sticky_pinnedBar");

  // ---- state ----
  I.crmHeaderId = String(root.getAttribute("data-crm-header") || "");
  // Boundaries: optional container where floating cards may be dragged/resized.
  // This will be set via setCrmHeaderId(id, areaId). If provided, drag and resize
  // operations will be clamped to this element's bounding rect. When null, the
  // entire viewport is used as the bounds.
  I.crmAreaId = String(root.getAttribute("data-crm-area") || "");
  I.floatingZ = 9055;
  // Maintain a separate sequence counter for toast notes. Each toast is
  // assigned a unique sequence number that determines its vertical
  // position within the toast stack. Lower sequence numbers appear
  // closer to the bottom of the stack. When a toast is removed (by
  // docking, dragging or closing), its sequence number is recycled and
  // can be reused by the next note to fill the gap.
  I.toastSeqCounter = 1;
  I.freeToastSeq = [];
  /**
   * Allocate the next available toast sequence. If there are previously
   * freed sequences, reuse the smallest one so that new toasts occupy
   * the lowest possible position in the stack. Otherwise return a new
   * sequence and increment the counter.
   */
  I.allocToastSeq = () => {
    if (Array.isArray(I.freeToastSeq) && I.freeToastSeq.length > 0) {
      // Sort ascending and shift the smallest value
      I.freeToastSeq.sort((a, b) => a - b);
      return I.freeToastSeq.shift();
    }
    const seq = I.toastSeqCounter;
    I.toastSeqCounter += 1;
    return seq;
  };
  /**
   * Release a toast sequence when a toast leaves the stack. Pushing
   * the sequence onto the free list makes it available for reuse by
   * subsequent toasts. Invalid values are ignored.
   */
  I.releaseToastSeq = (seq) => {
    if (Number.isFinite(seq)) {
      I.freeToastSeq.push(seq);
    }
  };

  /**
   * Remove a sequence number from the free pool when restoring a toast
   * into its original slot. This prevents the same sequence from being
   * allocated to a different card before the original has been inserted.
   */
  I.useToastSeq = (seq) => {
    if (!Number.isFinite(seq) || !Array.isArray(I.freeToastSeq)) return;
    const idx = I.freeToastSeq.indexOf(seq);
    if (idx >= 0) {
      I.freeToastSeq.splice(idx, 1);
    }
  };

  // ---- helpers ----
  I.getDir = () => {
    const d = root.getAttribute("dir") || document.documentElement.getAttribute("dir") || "rtl";
    return (String(d).toLowerCase() === "ltr") ? "ltr" : "rtl";
  };

  I.t = (k) => {
    // i18n loader may attach a function here
    try {
      return (typeof root.__sticky_t__ === "function") ? root.__sticky_t__(k) : k;
    } catch (_) {
      return k;
    }
  };

  I.sanitize = (s) => {
    // text-only sanitize (no HTML)
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  };

  // model factory
  // NOTE:
  // - sticky_id is the only identifier used for DOM lookups and callbacks.
  // - Date.now() fallback is intentionally kept for the TEST environment only.
  I.createModel = (payload) => {
    const sid = String(payload?.sticky_id || Date.now());

    // Thread comes from payload.thread and follows the reply schema:
    // { reply: [ { thread_order, username, user_avatar_link, user_full_name, text, created_at } ] }
    const threadArr = Array.isArray(payload?.thread)
      ? payload.thread
      : (Array.isArray(payload?.thread?.reply) ? payload.thread.reply : []);

    return {
      sticky_id: sid,
      state: String(payload?.state || "toast"),
      kind: String(payload?.kind || "info"),
      sender: String(payload?.sender || ""),
      // HTML segment (safe HTML from backend)
      html_segment: payload?.html_segment ?? "",
      // Thread data (chat)
      thread: threadArr,
      // Default colour aligns with the first entry in the palette (green).
      color: String(payload?.color || "green"),
      todos: Array.isArray(payload?.todos) ? payload.todos : [],
      pinned_seq: Number.isFinite(payload?.pinned_seq) ? payload.pinned_seq : null,
      x: Number.isFinite(payload?.x) ? payload.x : null,
      y: Number.isFinite(payload?.y) ? payload.y : null,
      w: Number.isFinite(payload?.w) ? payload.w : null,
      h: Number.isFinite(payload?.h) ? payload.h : null,
      // segments determine which parts of the card should be visible.
      // Defaults: header+thread on, html_segment/reply/content off.
      segments: {
        header: payload?.segments?.header !== undefined ? !!payload.segments.header : true,
        html_segment: payload?.segments?.html_segment !== undefined ? !!payload.segments.html_segment : false,
        thread: payload?.segments?.thread !== undefined ? !!payload.segments.thread : true,
        reply: payload?.segments?.reply !== undefined ? !!payload.segments.reply : false,
        content: payload?.segments?.content !== undefined ? !!payload.segments.content : false,
        todo: payload?.segments?.todo !== undefined ? !!payload.segments.todo : false,
      },
      // Admin/moderator flags for share button and permissions
      is_admin: payload?.is_admin !== undefined ? !!payload.is_admin : false,
      is_moderator: payload?.is_moderator !== undefined ? !!payload.is_moderator : false,
      // Shared users list (renamed from shared_with)
      shared_users: Array.isArray(payload?.shared_users) ? payload.shared_users : [],
      // Current username for thread message detection
      username: String(payload?.username || payload?.from_user?.username || ''),
      // Deprecated: from_user (kept for backward compatibility, use username instead)
      from_user: payload?.from_user || {},
    };
  };

  // Helper: build a full payload for STORE/SHARE/etc.
  // (DELETE/ARCHIVE/REPLY have their own minimal payload rules)
  I.buildFullPayload = (model, overrides = {}) => {
    return {
      sticky_id: model?.sticky_id,
      state: model?.state,
      kind: model?.kind,
      sender: model?.sender,
      html_segment: model?.html_segment,
      thread: { reply: Array.isArray(model?.thread) ? model.thread : [] },
      color: model?.color,
      todos: Array.isArray(model?.todos) ? model.todos : [],
      pinned_seq: model?.pinned_seq,
      x: model?.x,
      y: model?.y,
      w: model?.w,
      h: model?.h,
      segments: model?.segments,
      is_admin: model?.is_admin,
      is_moderator: model?.is_moderator,
      shared_users: Array.isArray(model?.shared_users) ? model.shared_users : [],
      username: model?.username,
      from_user: model?.from_user,
      ...overrides,
    };
  };

  // deterministic floating spawn (used by cards/api if they call it)
  // In RTL mode, new floating cards should spawn from the bottom-left of
  // the viewport; in LTR mode they should spawn from the bottom-right.
  // To achieve a deterministic and non-overlapping layout we compute
  // horizontal and vertical offsets. The x value always represents
  // the distance from the physical left edge; buildFloatingCard will
  // convert it to a distance from the right edge in LTR mode. The y
  // value represents the distance from the bottom edge (bottom offset).
  let spawnIndex = 0;
  I.nextFloatingSpawnXY = () => {
    // horizontal base offset: start near the edge but leave breathing room
    const baseX = 16;
    // vertical base offset (distance from bottom for the first card)
    const baseY = 16;
    // offsets between cards. We use a large vertical step so that even
    // tall cards won't overlap. If the cards exceed the available height,
    // they will wrap into a new column.
    const stepX = 320;
    const stepY = 320;
    const cols = 1; // single column layout

    const i = spawnIndex++;
    const col = (i % cols);
    const row = Math.floor(i / cols);
    const x = baseX + col * stepX;
    const y = baseY + row * stepY;
    return { x, y };
  };

  // ---- pinned under header (NO hardcode) ----
  function getHeaderEl() {
    const id =
      String(I.crmHeaderId || "") ||
      String(root.getAttribute("data-crm-header") || "");
    return id ? document.getElementById(id) : null;
  }

  // Retrieve the CRM area element within which floating cards should remain.
  function getAreaEl() {
    const id =
      String(I.crmAreaId || "") ||
      String(root.getAttribute("data-crm-area") || "");
    return id ? document.getElementById(id) : null;
  }

  // Compute the bounding rectangle of the allowed drag/resizing area. Falls
  // back to the viewport if no area element exists.
  I.getBounds = () => {
    const area = getAreaEl();
    if (area) {
      const r = area.getBoundingClientRect();
      return { left: r.left, top: r.top, right: r.right, bottom: r.bottom };
    }
    return { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight };
  };

  function syncPinnedUnderHeader() {
    const bar = I.pinnedBar;
    if (!bar) return;

    const header = getHeaderEl();
    const headerBottom = header ? Math.round(header.getBoundingClientRect().bottom) : 0;

    // pinned دقیقاً زیر هدر + فاصله
    const topPx = headerBottom + 8;
    bar.style.setProperty('--pinned-top', topPx + 'px');

    // رزرو فضا برای اینکه pinned روی محتوا/دکمه نیفته
    const barH = Math.round(bar.offsetHeight || 0);
    root.style.setProperty('--root-padding', (topPx + barH + 12) + 'px');
  }

  I.syncPinnedUnderHeader = syncPinnedUnderHeader;

  // observe pinned children changes (pin/restore)
  try {
    const mo = new MutationObserver(() => syncPinnedUnderHeader());
    if (I.pinnedBar) mo.observe(I.pinnedBar, { childList: true, subtree: false });
  } catch (_) {}

  // resize handling
  window.addEventListener("resize", syncPinnedUnderHeader);

  // if header size changes (optional)
  try {
    const header = getHeaderEl();
    if (header && "ResizeObserver" in window) {
      const ro = new ResizeObserver(() => syncPinnedUnderHeader());
      ro.observe(header);
    }
  } catch (_) {}

  // first sync after paint
  setTimeout(syncPinnedUnderHeader, 0);
})();