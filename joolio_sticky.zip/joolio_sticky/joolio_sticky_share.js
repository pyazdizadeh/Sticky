(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  function openShareModal(model) {
    const prev = document.querySelector('.sticky_shareOverlay');
    if (prev && prev.parentElement) {
      prev.parentElement.removeChild(prev);
    }

    const overlay = document.createElement('div');
    overlay.className = 'sticky_shareOverlay';
    overlay.addEventListener('click', (ev) => {
      if (ev.target === overlay) {
        overlay.parentElement?.removeChild(overlay);
      }
    });

    const modal = document.createElement('div');
    modal.className = 'sticky_shareModal sticky_card';
    modal.setAttribute('data-sticky-color', String(model.color || 'green'));

    const isModerator = model.is_moderator || model.is_admin || false;

    // 2.1: HEADER
    const titleEl = document.createElement('div');
    titleEl.className = 'sticky_shareTitle';
    titleEl.textContent = 'کاربران مشارکت کننده';
    // titleEl.style.cssText = 'font-weight: 700; font-size: 16px; text-align: center; padding: 12px; color: rgba(255,255,255,0.95);';
    modal.appendChild(titleEl);

    const closeModalBtn = document.createElement('button');
    closeModalBtn.className = 'sticky_shareClose';
    closeModalBtn.type = 'button';
    closeModalBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 34 34" fill="none"><path d="M11 11L23 23M23 11L11 23" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    closeModalBtn.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      overlay.parentElement?.removeChild(overlay);
    });
    modal.appendChild(closeModalBtn);

    // 2.2: SHARED USERS TABLE
    const sharedUsers = Array.isArray(model.shared_users) ? model.shared_users : [];
    
    if (sharedUsers.length > 0) {
      const table = document.createElement('table');
      table.className = 'sticky_sharedTable';
      // table.style.cssText = 'width: 100%; border-collapse: collapse; margin: 8px 0;';
      
      const thead = document.createElement('thead');
      thead.innerHTML = `
        <tr>
          <th class="sticky_thNum">#</th>
          <th class="sticky_thName">نام</th>
          <th class="sticky_thRole">نقش</th>
          <th class="sticky_thAction">عملیات</th>
        </tr>
      `;
      table.appendChild(thead);
      
      const tbody = document.createElement('tbody');
      
      sharedUsers.forEach((user, index) => {
        const tr = document.createElement('tr');
        const isFirstUser = index === 0;
        
        const tdNum = document.createElement('td');
        tdNum.className = 'sticky_tdNum';
        // tdNum.style.cssText = 'padding: 8px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 14px;';
        tdNum.textContent = String(index + 1);
        tr.appendChild(tdNum);
        
        const tdName = document.createElement('td');
        tdName.className = 'sticky_tdName';
        // tdName.style.cssText = 'padding: 8px; text-align: right; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 14px;';
        tdName.textContent = user.user_full_name || user.username || '';
        tr.appendChild(tdName);
        
        const tdRole = document.createElement('td');
        tdRole.className = 'sticky_tdRole';
        // tdRole.style.cssText = 'padding: 8px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.05);';
        const roleSpan = document.createElement('span');
        roleSpan.className = isFirstUser ? 'sticky_roleBadge_moderator' : 'sticky_roleBadge_user';
        // roleSpan.style.cssText = isFirstUser 
        //   ? 'display: inline-block; padding: 4px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; background: rgba(251,191,36,0.2); color: rgb(251,191,36); border: 1px solid rgba(251,191,36,0.3);'
        //   : 'display: inline-block; padding: 4px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.8); border: 1px solid rgba(255,255,255,0.2);';
        roleSpan.textContent = isFirstUser ? 'مدیر' : 'کاربر';
        tdRole.appendChild(roleSpan);
        tr.appendChild(tdRole);
        
        const tdAction = document.createElement('td');
        tdAction.className = 'sticky_tdAction';
        // tdAction.style.cssText = 'padding: 8px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.05);';
        
        if (!isFirstUser && isModerator) {
          const removeBtn = document.createElement('button');
          removeBtn.type = 'button';
          removeBtn.className = 'sticky_sharedRemoveBtn';
          removeBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 34 34" fill="none"><path d="M20 10H23C24.1046 10 25 10.8954 25 12V22C25 23.1046 24.1046 24 23 24H20" stroke="#FF0000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 12L11 17L16 22" stroke="#FF0000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M11 17H20" stroke="#FF0000" stroke-width="2" stroke-linecap="round"/></svg>';
          // removeBtn.style.cssText = 'background: none; border: none; cursor: pointer; padding: 4px; display: inline-flex; align-items: center; justify-content: center; opacity: 0.7; transition: opacity 0.2s;';
          removeBtn.title = 'خروج';
          // removeBtn.addEventListener('mouseenter', () => removeBtn.style.opacity = '1');
          // removeBtn.addEventListener('mouseleave', () => removeBtn.style.opacity = '0.7');
          removeBtn.addEventListener('click', (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            
            // 1. اول callback را فراخوانی کن
            if (typeof I.REMOVE_SHARED_USER === 'function') {
              I.REMOVE_SHARED_USER({
                sticky_id: model.sticky_id,
                username: user.username
              });
            }
            
            // 2. حذف از آرایه shared_users
            if (Array.isArray(model.shared_users)) {
              const userIndex = model.shared_users.findIndex(u => u.username === user.username);
              if (userIndex !== -1) {
                model.shared_users.splice(userIndex, 1);
              }
            }
            
            // 3. حذف از UI
            tr.remove();
          });
          tdAction.appendChild(removeBtn);
        } else {
          tdAction.textContent = '-';
        }
        
        tr.appendChild(tdAction);
        tbody.appendChild(tr);
      });
      
      table.appendChild(tbody);
      modal.appendChild(table);
    }

    // 2.3: HR
    if (isModerator) {
      const hr1 = document.createElement('hr');
      hr1.className = 'sticky_shareHR';
      // hr1.style.cssText = 'border: none; border-top: 1px solid rgba(255,255,255,0.1); margin: 12px 0;';
      modal.appendChild(hr1);
    }

    // 2.4: SELECT2
    let selectedUser = null;
    
    if (isModerator) {
      const input = document.createElement('input');
      input.className = 'sticky_shareInput';
      input.type = 'text';
      input.placeholder = 'نام کاربر را جستجو کنید...';
      // input.style.cssText = 'width: 100%; padding: 10px 12px; border: 1px solid rgba(255,255,255,0.2); background: rgba(255,255,255,0.05); color: rgba(255,255,255,0.9); border-radius: 8px; font-size: 14px; outline: none;';
      modal.appendChild(input);

      const results = document.createElement('div');
      results.className = 'sticky_shareResults';
      // results.style.cssText = 'max-height: 150px; overflow-y: auto; margin-top: 8px;';
      modal.appendChild(results);

      function renderResults(list) {
        results.innerHTML = '';
        if (!Array.isArray(list) || list.length === 0) return;
        
        list.forEach((item) => {
          const user = (typeof item === 'object') ? item.username || item.name || item.id || '' : item;
          const label = (typeof item === 'object') ? (item.name || item.username || item.id || '') : item;
          if (!user) return;
          
          const el = document.createElement('div');
          el.className = 'sticky_shareResult';
          el.textContent = String(label);
          // el.style.cssText = 'padding: 10px 12px; cursor: pointer; border-radius: 6px; margin: 4px 0; background: rgba(255,255,255,0.05); transition: background 0.2s; font-size: 14px;';
          // el.addEventListener('mouseenter', () => el.style.background = 'rgba(255,255,255,0.1)');
          // el.addEventListener('mouseleave', () => {
          //   if (!el.classList.contains('sticky_selected')) {
          //     el.style.background = 'rgba(255,255,255,0.05)';
          //   }
          // });
          el.addEventListener('click', (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            selectedUser = String(user);
            results.querySelectorAll('.sticky_shareResult').forEach((r) => {
              r.classList.remove('sticky_selected');
              // r.style.background = 'rgba(255,255,255,0.05)';
            });
            el.classList.add('sticky_selected');
            // el.style.background = 'rgba(255,255,255,0.15)';
          });
          results.appendChild(el);
        });
      }

      let searchTimeout = null;
      input.addEventListener('input', () => {
        const q = input.value.trim();
        selectedUser = null;
        results.innerHTML = '';
        if (!q) return;
        
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
          if (typeof I.SEARCH_USERS === 'function') {
            try {
              const ret = I.SEARCH_USERS({ query: q });
              Promise.resolve(ret).then((arr) => {
                if (Array.isArray(arr)) {
                  renderResults(arr);
                }
              }).catch(() => {});
            } catch (_) {}
          }
        }, 300);
      });

      // 2.5: HR
      const hr2 = document.createElement('hr');
      hr2.className = 'sticky_shareHR';
      // hr2.style.cssText = 'border: none; border-top: 1px solid rgba(255,255,255,0.1); margin: 12px 0;';
      modal.appendChild(hr2);

      // 2.6: دکمه دعوت
      const submitBtn = document.createElement('button');
      submitBtn.className = 'sticky_shareSubmit';
      submitBtn.type = 'button';
      submitBtn.textContent = 'دعوت کاربر';
      // submitBtn.style.cssText = 'width: 100%; padding: 12px; background: rgba(34,197,94,0.2); color: rgb(34,197,94); border: 1px solid rgba(34,197,94,0.3); border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s;';
      // submitBtn.addEventListener('mouseenter', () => {
      //   submitBtn.style.background = 'rgba(34,197,94,0.3)';
      // });
      // submitBtn.addEventListener('mouseleave', () => {
      //   submitBtn.style.background = 'rgba(34,197,94,0.2)';
      // });
      submitBtn.addEventListener('click', (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        if (!selectedUser) return;
        
        if (typeof I.SHARE === 'function') {
          try {
            I.SHARE({
              sticky_id: model.sticky_id,
              username: selectedUser
            });
          } catch (_) {}
        }
        
        overlay.parentElement?.removeChild(overlay);
      });
      modal.appendChild(submitBtn);
    }

    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    overlay.classList.add('sticky_visible');
  }

  I.showDeleteConfirmModal = (model, onConfirm) => {
    const overlay = document.createElement('div');
    overlay.className = 'sticky_shareOverlay';
    
    const modal = document.createElement('div');
    modal.className = 'sticky_shareModal sticky_card sticky_confirmModal';
    modal.setAttribute('data-sticky-color', String(model.color || 'green'));
    modal.setAttribute('data-sticky-state', model.state || 'floating');
    
    const message = document.createElement('div');
    message.className = 'sticky_confirmMessage';
    message.textContent = 'این کارت با کاربران دیگری اشتراک‌گذاری شده است. آیا از حذف آن مطمئن هستید؟';
    modal.appendChild(message);
    
    const buttons = document.createElement('div');
    buttons.className = 'sticky_confirmButtons';
    
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'sticky_confirmBtn sticky_confirmCancel';
    cancelBtn.textContent = 'انصراف';
    cancelBtn.addEventListener('click', () => {
      overlay.remove();
    });
    
    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'sticky_confirmBtn sticky_confirmOk';
    confirmBtn.textContent = 'تأیید حذف';
    confirmBtn.addEventListener('click', () => {
      overlay.remove();
      if (typeof onConfirm === 'function') onConfirm();
    });
    
    buttons.appendChild(cancelBtn);
    buttons.appendChild(confirmBtn);
    modal.appendChild(buttons);
    
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    overlay.classList.add('sticky_visible');
  };

  I.openShareModal = openShareModal;
})();
