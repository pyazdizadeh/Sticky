(() => {
  const root = document.getElementById("sticky_root");
  if (!root) return;

  const DICT = {
    fa: {
      btn_create: "ایجاد کارت خالی",
      reply_placeholder: "پاسخ را بنویسید...",
      todo_placeholder: "آیتم جدید...",
      todo_child_placeholder: "زیرتسک...",
      todo_title: "Todo",
      pinned_title: "Pinned",
      aria_close: "بستن",
      aria_pin: "سنجاق",
      aria_unpin: "بازگردانی",
      aria_color: "رنگ",
      aria_reply: "پاسخ",
      aria_send: "ارسال",
      // متون مربوط به پنجره اشتراک‌گذاری
      share_title: "اشتراک‌گذاری کارت",
      share_search_placeholder: "نام کاربر را وارد کنید...",
      share_submit: "ثبت",
      // برچسب‌های دسترس‌پذیری برای آیکون‌های جدید
      aria_share: "اشتراک‌گذاری",
      aria_archive: "آرشیو",
      aria_dock: "داک"
    },
    en: {
      btn_create: "Create empty card",
      reply_placeholder: "Type your reply…",
      todo_placeholder: "New item…",
      todo_child_placeholder: "Subtask…",
      todo_title: "Todo",
      pinned_title: "Pinned",
      aria_close: "Close",
      aria_pin: "Pin",
      aria_unpin: "Restore",
      aria_color: "Color",
      aria_reply: "Reply",
      aria_send: "Send",
      // Share modal texts
      share_title: "Share card",
      share_search_placeholder: "Type a username...",
      share_submit: "Submit",
      // Accessibility labels for new icons
      aria_share: "Share",
      aria_archive: "Archive",
      aria_dock: "Dock"
    }
  };

  root.__sticky_i18n__ = DICT;
  root.__sticky_t__ = (key) => {
    const lang = String(root.getAttribute("data-lang") || "fa").toLowerCase();
    return (DICT?.[lang]?.[key]) ?? "";
  };
})();