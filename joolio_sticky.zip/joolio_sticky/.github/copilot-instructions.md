<!-- Copilot / AI agent instructions for the JOOLIO Sticky Cards repo -->
# JOOLIO Sticky — Copilot Instructions

Purpose: give coding agents the essential, actionable knowledge to work on this small static JS widget.

- **Big picture:** The package is a client-side sticky-card widget composed of a small core, card builders, and feature modules. The runtime exposes a global `JOOLIOSticky` object; internal state and helpers live on `JOOLIOSticky.__internal` (see `joolio_sticky_core.js`).

- **Major components:**
  - Core & state: `joolio_sticky_core.js` — DOM refs, model factory, toast sequence allocator, spawn logic, bounds handling.
  - Public API: `joolio_sticky_api.js` — `JOOLIOSticky.create`, `createMany`, `clearAll`, `setCallbacks`, `setCrmHeaderId`, `setLang`.
  - Card rendering: `joolio_sticky_cards.js` — `I.buildToastCard` and `I.buildFloatingCard`, reply handling, optimistic UI for threads.
  - Feature modules: `joolio_sticky_drag.js`, `joolio_sticky_color.js`, `joolio_sticky_share.js`, `joolio_sticky_toast_layout.js`, `joolio_sticky_spacer_pinned.js`, `joolio_sticky_todo.js`, `joolio_sticky_autohide.js` (each augments `I` with behaviours).
  - Integration entry: `index.html` shows initialization examples and two debug buttons (`testFull` and `testTodo`) used to exercise the widget.

- **Key data flows & conventions:**
  - `sticky_id` is the unique identifier used for DOM lookups and callbacks.
  - Models are created via `I.createModel(payload)`; only `sticky_id` is required and `Date.now()` can be used for tests.
  - Toast vs Floating: presence of numeric `x` & `y` determines floating cards; otherwise a toast (sequence managed by `allocToastSeq` / `releaseToastSeq`).
  - RTL-first design: default `dir="rtl"` in `index.html`; spawn and positioning logic account for `I.getDir()`.
  - Root container attributes: `sticky_root` may carry `data-crm-header` and `data-crm-area` to bind the pinned bar and drag bounds.

- **Extension & integration points (what agents should modify or call):**
  - To create cards: call `JOOLIOSticky.create({ sticky_id, html_segment, todos, shared_users, position, segments })` — see `index.html` test handlers for examples.
  - Persist / lifecycle hooks: supply handlers via `JOOLIOSticky.setCallbacks({ store_sticky, delete_sticky, reply_sticky, archive_sticky, share_sticky, remove_shared_user, search_users })` — these are stored on `I` (e.g., `I.STORE`).
  - Share modal: `I.openShareModal(model)` should be defined by `joolio_sticky_share.js`; code expects it to exist when share button is used.

- **Project-specific patterns agents must follow:**
  - Avoid mutating the original payload; code clones model objects before adding metadata (see `joolio_sticky_api.js`).
  - Use the internal `I.buildFullPayload(model, overrides)` when calling `STORE` to ensure expected fields are present.
  - Sequence reuse: when docking/restoring toasts, the code preserves `model.__seq` and uses `I.releaseToastSeq` / `I.useToastSeq` — do not bypass these helpers.
  - UI elements and CSS classes are stable API surfaces: `sticky_root`, `sticky_toasts`, `sticky_floating`, `sticky_pinnedBar`, and card classes such as `sticky_card`, `sticky_cardWithHeader`, `sticky_replyInput`.

- **Developer workflows & testing:**
  - No build step: files are plain JS/CSS/HTML. To test, open `index.html` in a browser (or a simple static server) and use the `تست کامل` / `تست TODO` buttons to exercise scenarios.
  - Console logging: `index.html` logs `JOOLIOSticky` and checks for `__internal.openShareModal` during startup — use these checks when debugging.

- **Quick examples from the repo:**
  - Create a full card (from `index.html`):
    - `JOOLIOSticky.create({ sticky_id: 'FULL-123', html_segment: '<div>...</div>', todos: [...], shared_users: [...], position: { x:50, y:50 } })`
  - Set callbacks (from `index.html`):
    - `JOOLIOSticky.setCallbacks({ store_sticky: (p) => console.log('STORE', p.sticky_id), search_users: ({query}) => [...] })`

- **When editing code, watch for:**
  - Side-effects on `I` — modules intentionally augment the `I` namespace rather than exporting separate modules.
  - RTL assumptions in positioning code (`nextFloatingSpawnXY`, floating `--floating-x` logic).
  - Sequence allocation vs floating coordinates semantics (do not mix the two accidentally).

If anything here is unclear or you'd like me to expand examples (e.g., more sample payloads, or a short test harness), tell me which section to iterate on.
