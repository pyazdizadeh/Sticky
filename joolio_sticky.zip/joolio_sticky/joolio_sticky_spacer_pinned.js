(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  I.makeSpacerFromCard = (cardEl, stickyId) => {
    const r = cardEl.getBoundingClientRect();
    const sp = document.createElement("div");
    sp.className = "sticky_spacer";
    sp.style.height = Math.max(0, Math.round(r.height)) + "px";
    sp.dataset.spacer = "1";
    sp.setAttribute('data-sticky-id', String(stickyId || ""));
    return sp;
  };

  I.removeSpacerById = (stickyId) => {
    const safeId = String(stickyId || "");
    const all = I.toasts.querySelectorAll('.sticky_spacer[data-spacer="1"]');
    for (let i = 0; i < all.length; i++){
      if (all[i].getAttribute('data-sticky-id') === safeId) {
        all[i].remove();
        return;
      }
    }
  };

  I.createPinnedTab = (model) => {
    const tab = document.createElement("div");
    tab.className = "sticky_pinnedTab";
    tab.setAttribute('data-sticky-id', String(model.sticky_id || ''));
    tab.dataset.seq = String(model.__seq || "");

    // همسان‌سازی رنگ pinned با رنگ کارت
    // اگر مدل رنگی دارد، آن را به data-sticky-color اضافه می‌کنیم تا CSS بتواند ظاهر را تنظیم کند
    const colorKey = (typeof model.color === "string" && model.color) ? model.color : "red";
    tab.setAttribute("data-sticky-color", colorKey);

    // Build a snippet for the pinned tab based on the START of the chat (thread).
    // Requirement: "خلاصه pin میشود قسمتی از اول چت".
    const firstMsg = Array.isArray(model?.thread) ? model.thread[0] : null;
    const firstText = firstMsg ? String(firstMsg.text || '') : '';
    const snippet = firstText ? firstText.slice(0, 90) : (I.t("pinned_fallback") || "Sticky");
    // Render the snippet in the tab
    tab.innerHTML = `<div class="sticky_pinnedTabSummary">${I.sanitize(snippet)}</div>`;

    // Create a tooltip containing more of the initial thread text.
    // The tooltip is hidden by default and displayed via CSS on hover of the tab.
    const tooltip = document.createElement('div');
    tooltip.className = 'sticky_pinnedTooltip';
    tooltip.setAttribute('data-sticky-color', colorKey);
    tooltip.innerHTML = `
      <div class="sticky_tooltipTitle">${I.sanitize(I.t ? (I.t('pinned_thread') || '') : '')}</div>
      <div class="sticky_tooltipBody">${I.sanitize(firstText)}</div>
    `;
    tab.appendChild(tooltip);

    tab.addEventListener("click", () => {
      // Restore the card based on the state it had prior to docking. When the
      // card was originally a toast, reinsert it into the toast stack at
      // its original sequence. Otherwise rebuild it as a floating card.
      if (model.prevState === "toast") {
        model.state = "toast";
        // Remove this sequence from the free pool so it can be reused
        // by the card being restored. Without this the sequence might
        // have been allocated to a different toast after docking.
        I.useToastSeq(model.__seq);
        const card = I.buildToastCard(model);
        I.toasts.appendChild(card);
        // Persist the state change. Do not include x/y because the toast
        // layout determines placement based on the sequence number.
        if (typeof I.STORE === "function") {
          I.STORE(I.buildFullPayload(model, { state: model.state }));
        }
      } else {
        model.state = "floating";
        const card = I.buildFloatingCard(model);
        I.floating.appendChild(card);
        // Persist floating coordinates
        if (typeof I.STORE === "function") {
          I.STORE(I.buildFullPayload(model, { state: model.state }));
        }
      }
      // Remove the pinned tab after restoring
      tab.remove();
    });

    I.pinnedBar.appendChild(tab);
  };
})();

