(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  /**
   * Attach auto‑hide behaviour to toast cards. A timer starts when the
   * pointer leaves the card; after three seconds of inactivity the card
   * begins to fade out over two seconds. If the pointer re‑enters the
   * card during this period, the fade is cancelled and the timer
   * restarts when the pointer leaves again. After the card has fully
   * faded, it is removed from the DOM and the DELETE callback is
   * invoked with the card id.
   *
   * @param {HTMLElement} cardEl The card element to hide automatically
   * @param {Object} model The card’s model containing the id and state
   */
  function setupAutoHide(cardEl, model) {
    // Only attach to toast cards (state === 'toast' or no coords). Skip
    // floating, docked or shared cards where auto hide should not occur.
    if (!model || model.state !== 'toast') return;
    // When a card has been shared or explicitly marked as no auto hide,
    // do not attach the hide behaviour.  The share callback sets
    // model.noAutoHide so shared cards remain visible.
    if (model.noAutoHide) return;
    let hideTimer = null;
    let fadeTimer = null;

    const startHideCountdown = () => {
      // Clear any existing timers
      clearTimeout(hideTimer);
      clearTimeout(fadeTimer);
      // Wait 5 seconds before starting fade (total 8 seconds until removal).
      // The last 3 seconds are used for the fade‑out animation.
      hideTimer = setTimeout(() => {
        // Begin fade out
        cardEl.classList.add('sticky_fadeOut');
        // Remove after 3 seconds
        fadeTimer = setTimeout(() => {
          // If the card has not been removed already (e.g. docked), delete it
          if (cardEl && cardEl.parentElement) {
            cardEl.remove();
            // Release its toast sequence so new cards can reuse the slot
            if (Number.isFinite(model.__seq)) {
              I.releaseToastSeq(model.__seq);
            }
            // Invoke delete callback with card id
            if (typeof I.DELETE === 'function') I.DELETE({ sticky_id: model.sticky_id });
          }
        }, 3000);
      }, 5000);
    };

    const cancelHide = () => {
      clearTimeout(hideTimer);
      clearTimeout(fadeTimer);
      // Reset opacity instantly by removing fade class
      cardEl.classList.remove('sticky_fadeOut');
    };
    // Start timer when pointer leaves
    cardEl.addEventListener('mouseleave', startHideCountdown);
    // Cancel timer when pointer enters
    cardEl.addEventListener('mouseenter', cancelHide);

    // Immediately start the countdown when the card is created. This ensures
    // that a toast card will fade out even if the mouse never enters it.
    // The countdown will restart whenever the mouse leaves the card.
    startHideCountdown();
  }

  // Save the setup function for use by the cards module
  I.__autoHideSetup = setupAutoHide;

  // Monkey‑patch buildToastCard to install auto hide on new toast cards
  const origBuildToast = I.buildToastCard;
  I.buildToastCard = (m) => {
    const cardEl = origBuildToast(m);
    // If the card is created as a toast, attach auto hide handlers
    if (m && (m.state === 'toast' || (!Number.isFinite(m.x) && !Number.isFinite(m.y)))) {
      setupAutoHide(cardEl, m);
    }
    return cardEl;
  };
})();