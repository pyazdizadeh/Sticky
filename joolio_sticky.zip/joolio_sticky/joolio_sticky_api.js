(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  api.create = (payload) => {
    const base = I.createModel(payload);
    // Clone the base model so we can add additional metadata without
    // mutating the original payload object. The sequence number (__seq) for
    // toast notes is allocated here. For floating cards the sequence is
    // preserved from any previous state (e.g. when restoring from dock).
    const model = { ...base };

    // Determine whether we have explicit coordinates. A card with both x
    // and y finite values will be treated as a floating card. When either
    // coordinate is missing, the card defaults to a toast. User‑provided
    // state values are ignored to ensure consistent behaviour.
    const hasCoords = Number.isFinite(model.x) && Number.isFinite(model.y);

    if (hasCoords) {
      // Floating card: preserve the existing sequence if any. When restoring
      // from dock, model.__seq may already be set and must not be changed.
      // Assign a sequence if it doesn’t exist so the element still carries
      // a valid data attribute (though floating cards aren’t ordered by it).
      if (!Number.isFinite(model.__seq)) {
        model.__seq = 0;
      }
      model.state = 'floating';
      // Use deterministic spawn offsets when coordinates are missing to
      // avoid overlap between floating cards. Coordinates provided via
      // payload override the spawn algorithm.
      if (typeof I.nextFloatingSpawnXY === 'function') {
        const { x, y } = I.nextFloatingSpawnXY();
        if (!Number.isFinite(model.x)) model.x = x;
        if (!Number.isFinite(model.y)) model.y = y;
      }
      const card = I.buildFloatingCard(model);
      I.floating.appendChild(card);
    } else {
      // Toast card: allocate a new sequence number for placement within the
      // stack. If the model already carries a __seq (e.g. restore), reuse
      // it; otherwise allocate a fresh one. Coordinates are cleared to
      // prevent them from leaking into a floating context later on.
      if (!Number.isFinite(model.__seq)) {
        model.__seq = I.allocToastSeq();
      }
      model.state = 'toast';
      delete model.x;
      delete model.y;
      const card = I.buildToastCard(model);
      // Append the card to the toasts container. Ordering is determined
      // solely by the sequence numbers; DOM order is irrelevant because
      // the layout module sorts elements by their data-sticky-seq.
      I.toasts.appendChild(card);
    }

    return model.sticky_id;
  };

  api.createMany = (arr) => {
    (Array.isArray(arr) ? arr : []).forEach(api.create);
  };

  api.clearAll = () => {
    I.toasts.innerHTML = "";
    I.floating.innerHTML = "";
    I.pinnedBar.innerHTML = "";
  };

  api.setCallbacks = ({ store_sticky, delete_sticky, reply_sticky, archive_sticky, share_sticky, remove_shared_user, search_users } = {}) => {
    // Provide callback assignments for all sticky lifecycle operations. If a
    // given handler is not a function, set it to null so that cards can
    // gracefully skip calling undefined callbacks.
    I.STORE = (typeof store_sticky === "function") ? store_sticky : null;
    I.DELETE = (typeof delete_sticky === "function") ? delete_sticky : null;
    I.REPLY = (typeof reply_sticky === "function") ? reply_sticky : null;
    // Optional callback for archive actions. When provided, it will be
    // invoked by the archive button in the card header.
    I.ARCHIVE = (typeof archive_sticky === "function") ? archive_sticky : null;
    // Callback for sharing a card with another user. When provided, this
    // function is invoked with an object containing the id, sticky_id and
    // username fields whenever the share modal's submit button is clicked.
    I.SHARE = (typeof share_sticky === "function") ? share_sticky : null;
    // Callback for removing a shared user from a card. When provided, this
    // function is invoked with an object containing sticky_id and username
    // whenever a user is removed from the shared users list.
    I.REMOVE_SHARED_USER = (typeof remove_shared_user === "function") ? remove_shared_user : null;
    // Callback for searching users. When provided, this function is called
    // whenever the user types into the share modal search field. It should
    // return (or resolve to) a list of user objects matching the query.
    I.SEARCH_USERS = (typeof search_users === "function") ? search_users : null;
  };

  // Assign the CRM header ID as well as an optional area ID. When areaId is
  // provided it is stored on the root so the drag/resize logic can limit
  // movement to the specified container.
  api.setCrmHeaderId = (id, areaId) => {
    I.root.setAttribute("data-crm-header", String(id || ""));
    if (areaId !== undefined) {
      I.root.setAttribute("data-crm-area", String(areaId || ""));
      I.crmAreaId = String(areaId || "");
    }
  };

  api.setLang = (lang) => {
    I.root.setAttribute("data-lang", String(lang || ""));
  };
})();

