(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  /*
   * Define reusable SVG icons for the header buttons. Each entry holds
   * the markup for a 34×34 icon with a white stroke. These icons are
   * injected directly into the button elements to replace the default
   * emoji or text glyphs. See user specification for details.
   */
  const SVG_ICONS = {
    // Cross icon used for the close button
    close: `<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none"><path d="M11 11L23 23M23 11L11 23" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    // Diamond‑shaped arrow used for the dock button
    dock: `<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none"><path d="M13 9.5H21L20 15.5L23.5 19H10.5L14 15.5L13 9.5Z" stroke="#FFFFFF" stroke-width="2" stroke-linejoin="round"/><path d="M17 19V26.5" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round"/></svg>`,
    // Abstract cloud/brush used for the palette button
    palette: `<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none"><path d="M17 8.5C11.7533 8.5 7.5 12.7533 7.5 18C7.5 23.2467 11.7533 27.5 17 27.5H19.2C20.5255 27.5 21.6 26.4255 21.6 25.1C21.6 24.2849 21.2796 23.5032 20.7094 22.9294C20.1352 22.3596 19.8148 21.5779 19.8148 20.7628C19.8148 19.0849 21.175 17.7246 22.8529 17.7246H24C26.4853 17.7246 28.5 15.7099 28.5 13.2246C28.5 10.4236 23.7467 8.5 17 8.5Z" stroke="#FFFFFF" stroke-width="2" stroke-linejoin="round"/><path d="M11.5 18.5H11.6" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/><path d="M14.5 13.5H14.6" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/><path d="M19.5 12.5H19.6" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/><path d="M23 14.5H23.1" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/></svg>`,
    // Tray icon used for the archive button
    archive: `<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none"><path d="M9.5 13.5H24.5V24.5C24.5 25.6046 23.6046 26.5 22.5 26.5H11.5C10.3954 26.5 9.5 25.6046 9.5 24.5V13.5Z" stroke="#FFFFFF" stroke-width="2" stroke-linejoin="round"/><path d="M8.5 9.5H25.5C26.0523 9.5 26.5 9.9477 26.5 10.5V12.5C26.5 13.0523 26.0523 13.5 25.5 13.5H8.5C7.9477 13.5 7.5 13.0523 7.5 12.5V10.5C7.5 9.9477 7.9477 9.5 8.5 9.5Z" stroke="#FFFFFF" stroke-width="2" stroke-linejoin="round"/><path d="M13 18H21" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round"/></svg>`
    ,
    // Share icon: three connected circles and arrows. This SVG is provided
    // by the user and matches the styling of other header icons.
    share: `<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none"><path d="M21 11L13 15.5" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M21 23L13 18.5" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="23" cy="10" r="3" stroke="#FFFFFF" stroke-width="2"/><circle cx="11" cy="17" r="3" stroke="#FFFFFF" stroke-width="2"/><circle cx="23" cy="24" r="3" stroke="#FFFFFF" stroke-width="2"/></svg>`
  };

  function getThreadItems(model) {
    const items = Array.isArray(model?.thread) ? model.thread : [];
    // Ensure deterministic order: old messages on top
    return [...items].sort((a, b) => {
      const ao = Number.isFinite(a?.thread_order) ? a.thread_order : 0;
      const bo = Number.isFinite(b?.thread_order) ? b.thread_order : 0;
      return ao - bo;
    });
  }

  function renderThreadHtml(model) {
    const items = getThreadItems(model);
    if (!items.length) {
      return `<div class="sticky_threadEmpty">${I.sanitize(I.t ? (I.t('thread_empty') || '') : '')}</div>`;
    }
    
    // Get current user username from model.username
    const currentUser = model?.username || '';
    
    return items.map((m) => {
      const avatar = String(m?.user_avatar_link || '');
      const fullName = String(m?.user_full_name || m?.username || '');
      const createdAt = String(m?.created_at || '');
      const text = String(m?.text || '');
      const messageUser = String(m?.username || '');
      
      // Check if this message is from current user
      const isSelf = currentUser && messageUser === currentUser;
      const selfClass = isSelf ? ' sticky_threadSelf' : '';
      
      return `
        <div class="sticky_threadMsg${selfClass}">
          ${avatar ? `<img class="sticky_threadAvatar" src="${I.sanitize(avatar)}" alt="" />` : `<div class="sticky_threadAvatar sticky_threadAvatarPlaceholder"></div>`}
          <div class="sticky_threadBubble">
            <div class="sticky_threadMeta">
              <span class="sticky_threadName">${I.sanitize(fullName)}</span>
              ${createdAt ? `<span class="sticky_threadTime">${I.sanitize(createdAt)}</span>` : ''}
            </div>
            <div class="sticky_threadText">${I.sanitize(text)}</div>
          </div>
        </div>
      `;
    }).join('');
  }

  // Limit HTML segment height to the card width (square-ish) to avoid very tall
  // injected HTML blocks. The backend HTML is considered safe per spec.
  function applyHtmlSegmentSizing(cardEl) {
    try {
      const htmlEl = cardEl && cardEl.querySelector ? cardEl.querySelector('.sticky_htmlSegment') : null;
      if (!htmlEl) return;
      const w = cardEl.getBoundingClientRect().width;
      if (w && Number.isFinite(w)) {
        htmlEl.style.setProperty('--segment-height', Math.round(w) + 'px');
      }
    } catch (e) {}
  }

  function addOptimisticThreadMessage(model, text) {
    if (!model) return;
    if (!Array.isArray(model.thread)) model.thread = [];
    const maxOrder = model.thread.reduce((mx, it) => {
      const o = Number.isFinite(it?.thread_order) ? it.thread_order : 0;
      return Math.max(mx, o);
    }, 0);
    model.thread.push({
      thread_order: maxOrder + 1,
      username: 'you',
      user_avatar_link: '',
      user_full_name: 'شما',
      text: String(text || ''),
      created_at: '',
    });
  }

  I.buildToastCard = (model) => {
    const c = document.createElement("div");
    c.className = "sticky_card";
    // Add a specific class for the header/drag area
    if (model.segments?.header !== false) {
      c.classList.add("sticky_cardWithHeader");
    }
    c.setAttribute('data-sticky-id', String(model.sticky_id || ''));
    // Store the sequence on the element so the toast layout can order
    // cards deterministically. Without this attribute, all cards sort the
    // same and ordering depends on DOM insertion order only.
    c.setAttribute('data-sticky-seq', String(model.__seq || ''));

    // Build the toast header. Include close, archive and dock buttons. The color
    // palette will be injected after the close button by the color module.
    c.innerHTML = `
      <button class="sticky_close" type="button" aria-label="close" title="${I.t ? (I.t('aria_close') || '') : ''}">${SVG_ICONS.close}</button>
      <!-- Place the dock button before the archive button so that docking is
           the first action icon in the sequence. The palette button will
           still be injected after the close button. -->
      <button class="sticky_dock" type="button" aria-label="dock" title="${I.t ? (I.t('aria_dock') || '') : ''}">${SVG_ICONS.dock}</button>
      <button class="sticky_archive" type="button" aria-label="archive" title="${I.t ? (I.t('aria_archive') || '') : ''}">${SVG_ICONS.archive}</button>
      <button class="sticky_share" type="button" aria-label="share" title="${I.t ? (I.t('aria_share') || '') : ''}">${SVG_ICONS.share}</button>

      <div class="sticky_htmlSegment">${String(model.html_segment || '')}</div>

      <div class="sticky_thread">
        ${renderThreadHtml(model)}
      </div>

      <div class="sticky_reply">
        <input class="sticky_replyInput" type="text" placeholder="${I.sanitize(I.t("reply_placeholder"))}" />
        <button class="sticky_send" type="button" aria-label="send">➤</button>
      </div>
    `;

    // Enforce html_segment max-height based on card width.
    applyHtmlSegmentSizing(c);


    // Apply segment visibility: hide sections based on model.segments. For
    // header, we hide the icons; for message and reply, remove the element.
    if (model && model.segments) {
      const segs = model.segments;
      if (segs.html_segment === false) {
        const htmlEl = c.querySelector('.sticky_htmlSegment');
        if (htmlEl) htmlEl.remove();
      }
      if (segs.thread === false) {
        const thEl = c.querySelector('.sticky_thread');
        if (thEl) thEl.remove();
      }
      if (segs.reply === false) {
        const repEl = c.querySelector('.sticky_reply');
        if (repEl) repEl.remove();
      }
      if (segs.header === false) {
        c.classList.add('sticky_headerHidden');
      }
    }

    /* The debug badge used to overlay a sequence number on the card. This has been
       deprecated. Instead, the sequence number is appended to the message
       content above if defined. */
    /* I.attachDebugBadge && I.attachDebugBadge(c, model.__seq); */

    const closeBtn = c.querySelector(".sticky_close");
    const dockBtn = c.querySelector(".sticky_dock");
    const archiveBtn = c.querySelector(".sticky_archive");
    const shareBtn = c.querySelector(".sticky_share");
    const input = c.querySelector(".sticky_replyInput");
    const sendBtn = c.querySelector(".sticky_send");

    // Attach close, dock and archive handlers only if the header is present
    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        // Remove the card completely and release its toast sequence. This
        // frees up the slot for future notes. We do not insert a
        // placeholder spacer; the layout algorithm will automatically
        // collapse the gap.
        c.remove();
        I.releaseToastSeq(model.__seq);
        if (typeof I.DELETE === "function") I.DELETE({ sticky_id: model.sticky_id });
      });
    }
    if (dockBtn) {
      dockBtn.addEventListener("click", () => {
        // Record that this card was previously in the toast so that restore
        // will return it to the same toast slot. Save the current sequence.
        model.prevState = "toast";

        const rect = c.getBoundingClientRect();
        const dir = (typeof I.getDir === "function") ? I.getDir() : "rtl";
        let newX;
        if (dir === "ltr") {
          const vw = window.innerWidth || document.documentElement.clientWidth;
          newX = Math.round(vw - rect.right);
        } else {
          newX = Math.round(rect.left);
        }
        model.x = newX;
        const vh = window.innerHeight || document.documentElement.clientHeight;
        model.y = Math.round(vh - rect.bottom);

        // Remove the card and release its toast sequence. This frees the
        // slot for future notes. When restored, the model.__seq is
        // preserved so the card can reclaim its position.
        c.remove();
        I.releaseToastSeq(model.__seq);

        // Create a docked tab and persist the new state.
        I.createPinnedTab(model);
        if (typeof I.STORE === "function") {
          I.STORE(I.buildFullPayload(model, { state: "docked" }));
        }
      });
    }
    if (archiveBtn) {
      archiveBtn.addEventListener("click", () => {
        // archive action placeholder; call the ARCHIVE callback if defined
        if (typeof I.ARCHIVE === "function") I.ARCHIVE({ sticky_id: model.sticky_id });
      });
    }

    // Share handler: open the share modal when the share button is clicked.
    if (shareBtn) {
      // Disable or hide the share button for non-admin users. When the
      // current model’s is_admin flag is false, prevent any interaction
      // and visually hide the icon by setting display: none. Otherwise
      // attach the click handler to open the share modal.
      if (!model.is_admin) {
        shareBtn.classList.add('sticky_shareHidden');
      } else {
        shareBtn.addEventListener("click", (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          if (typeof I.openShareModal === "function") {
            I.openShareModal(model);
          }
        });
      }
    }

    // Attach reply handler only if reply section is present
    if (input && sendBtn) {
      sendBtn.addEventListener("click", () => {
        const rawText = String(input.value || '').trim();
        if (!rawText) return;
        input.value = "";
        if (typeof I.REPLY === "function") I.REPLY({ sticky_id: model.sticky_id, text: rawText });

        // Optimistic UI: append the message to the thread and re-render
        addOptimisticThreadMessage(model, rawText);
        const threadEl = c.querySelector('.sticky_thread');
        if (threadEl) threadEl.innerHTML = renderThreadHtml(model);
      });
    }

    return c;
  };

  I.buildFloatingCard = (model) => {
    const c = document.createElement("div");
    c.className = "sticky_card";
    // Add a specific class for the header/drag area
    if (model.segments?.header !== false) {
      c.classList.add("sticky_cardWithHeader");
    }
    c.setAttribute('data-sticky-id', String(model.sticky_id || ''));
    // Propagate the sequence number to the DOM for consistency, though
    // floating cards are not ordered by seq.
    c.setAttribute('data-sticky-seq', String(model.__seq || ''));

    c.classList.add('sticky_floating');
    // تنظیم موقعیت افقی بر اساس جهت: برای RTL از چپ، برای LTR از راست
    {
      const defaultX = 16;
      const xVal = Number.isFinite(model.x) ? model.x : defaultX;
      c.style.setProperty('--floating-x', xVal + 'px');
    }
    // برای کارت‌های شناور، مختصات عمودی به عنوان فاصله از پایین تعریف می‌شود.
    // اگر مقدار y تعیین شده باشد (bottom offset)، از آن استفاده می‌کنیم، در غیر اینصورت 16px را در نظر می‌گیریم.
    c.style.setProperty('--floating-y', (Number.isFinite(model.y) ? model.y : 16) + 'px');
    c.style.setProperty('--floating-z', String(++I.floatingZ));

    // Build the floating card: close, pin and palette buttons will be injected by
    // other modules. We no longer render a dedicated drag handle because
    // dragging can occur from anywhere on the card body. The color button
    // will be inserted by the color module after build.
    // Build the floating card header: close, archive and dock. The color
    // palette is injected after the close button by the color module.
    c.innerHTML = `
      <button class="sticky_close" type="button" aria-label="close" title="${I.t ? (I.t('aria_close') || '') : ''}">${SVG_ICONS.close}</button>
      <!-- Place the dock button before the archive button to ensure the docking
           functionality is bound to the correct icon. The palette is
           injected after the close button. -->
      <button class="sticky_dock" type="button" aria-label="dock" title="${I.t ? (I.t('aria_dock') || '') : ''}">${SVG_ICONS.dock}</button>
      <button class="sticky_archive" type="button" aria-label="archive" title="${I.t ? (I.t('aria_archive') || '') : ''}">${SVG_ICONS.archive}</button>
      <button class="sticky_share" type="button" aria-label="share" title="${I.t ? (I.t('aria_share') || '') : ''}">${SVG_ICONS.share}</button>

      <div class="sticky_htmlSegment">${String(model.html_segment || '')}</div>

      <div class="sticky_thread">
        ${renderThreadHtml(model)}
      </div>

      <div class="sticky_reply">
        <input class="sticky_replyInput" type="text" placeholder="${I.sanitize(I.t("reply_placeholder"))}" />
        <button class="sticky_send" type="button" aria-label="send">➤</button>
      </div>
    `;

    // Enforce html_segment max-height based on card width.
    applyHtmlSegmentSizing(c);


    // Apply segment visibility: hide sections based on model.segments.
    if (model && model.segments) {
      const segs = model.segments;
      if (segs.html_segment === false) {
        const htmlEl = c.querySelector('.sticky_htmlSegment');
        if (htmlEl) htmlEl.remove();
      }
      if (segs.thread === false) {
        const thEl = c.querySelector('.sticky_thread');
        if (thEl) thEl.remove();
      }
      if (segs.reply === false) {
        const repEl = c.querySelector('.sticky_reply');
        if (repEl) repEl.remove();
      }
      if (segs.header === false) {
        c.classList.add('sticky_headerHidden');
      }
    }

    /* The debug badge used to overlay a sequence number on the card. This has been
       deprecated. Instead, the sequence number is appended to the message
       content above if defined. */
    /* I.attachDebugBadge && I.attachDebugBadge(c, model.__seq); */

    const closeBtn = c.querySelector(".sticky_close");
    const dockBtn = c.querySelector(".sticky_dock");
    const archiveBtn = c.querySelector(".sticky_archive");
    const shareBtn = c.querySelector(".sticky_share");
    const input = c.querySelector(".sticky_replyInput");
    const sendBtn = c.querySelector(".sticky_send");

    // Close handler only if button exists
    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        c.remove();
        if (typeof I.DELETE === "function") I.DELETE({ sticky_id: model.sticky_id });
      });
    }
    // Dock handler only if button exists
    if (dockBtn) {
      dockBtn.addEventListener("click", () => {
        // Record that this card was previously floating; restoring should
        // return it to the same floating coordinates rather than to toast.
        model.prevState = "floating";

        const rect = c.getBoundingClientRect();
        const dir = (typeof I.getDir === "function") ? I.getDir() : "rtl";
        let newX;
        if (dir === "ltr") {
          const vw = window.innerWidth || document.documentElement.clientWidth;
          newX = Math.round(vw - rect.right);
        } else {
          newX = Math.round(rect.left);
        }
        model.x = newX;
        const vh = window.innerHeight || document.documentElement.clientHeight;
        model.y = Math.round(vh - rect.bottom);

        c.remove();
        I.createPinnedTab(model);
        // Persist the updated model with all relevant fields for backend.
        if (typeof I.STORE === "function") {
          I.STORE(I.buildFullPayload(model, { state: "docked" }));
        }
      });
    }
    if (archiveBtn) {
      archiveBtn.addEventListener("click", () => {
        if (typeof I.ARCHIVE === "function") I.ARCHIVE({ sticky_id: model.sticky_id });
      });
    }

    // Share handler: open the share modal when the share button is clicked.
    if (shareBtn) {
      // Hide the share button if the user is not an admin. Otherwise attach
      // the click handler to invoke the share modal. This mirrors the
      // behaviour in the toast builder.
      if (!model.is_admin) {
        shareBtn.classList.add('sticky_shareHidden');
      } else {
        shareBtn.addEventListener("click", (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          if (typeof I.openShareModal === "function") {
            I.openShareModal(model);
          }
        });
      }
    }

    // Attach reply handler only if reply section exists
    if (input && sendBtn) {
      sendBtn.addEventListener("click", () => {
        const rawText = String(input.value || '').trim();
        if (!rawText) return;
        input.value = "";
        if (typeof I.REPLY === "function") I.REPLY({ sticky_id: model.sticky_id, text: rawText });

        // Optimistic UI: append the message to the thread and re-render
        addOptimisticThreadMessage(model, rawText);
        const threadEl = c.querySelector('.sticky_thread');
        if (threadEl) threadEl.innerHTML = renderThreadHtml(model);
      });
    }

    I.enableDragFloating && I.enableDragFloating(c, model);

    return c;
  };
})();

