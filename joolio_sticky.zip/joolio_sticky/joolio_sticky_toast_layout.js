(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  // Reduce the vertical gap between stacked toast cards from 12px to 10px
  const GAP = 10;

  function imp(el, prop, val){
    el.style.setProperty(prop, val, "important");
  }

  function lockHost(host){
    imp(host, "position", "fixed");
    imp(host, "left", "16px");
    imp(host, "right", "16px");
    imp(host, "bottom", "16px");
    imp(host, "top", "auto");
    imp(host, "height", "min(70vh, 520px)");
    imp(host, "pointer-events", "none");
    imp(host, "z-index", "9000");
    imp(host, "overflow", "hidden");
  }

  function measureHeights(items){
    const heights = new Array(items.length);

    for (let i = 0; i < items.length; i++){
      const el = items[i];
      imp(el, "position", "relative");
      imp(el, "left", "auto");
      imp(el, "right", "auto");
      imp(el, "top", "auto");
      imp(el, "bottom", "auto");
      imp(el, "margin", "0");
      imp(el, "visibility", "hidden");
      heights[i] = el.offsetHeight || 0;
    }

    for (let i = 0; i < items.length; i++){
      imp(items[i], "visibility", "visible");
    }

    return heights;
  }

  function applyAbsoluteStack(items, heights){
    let y = 0;

    // stack from bottom upward: last item sits at bottom
    for (let i = items.length - 1; i >= 0; i--){
      const el = items[i];

      imp(el, "position", "absolute");
      imp(el, "left", "0");
      imp(el, "right", "0");
      imp(el, "top", "auto");
      imp(el, "bottom", y + "px");
      imp(el, "margin", "0");

      if (el.classList.contains("sticky_spacer")) imp(el, "pointer-events", "none");
      else imp(el, "pointer-events", "auto");

      const h = heights[i] || el.offsetHeight || 0;
      y += h + GAP;
    }
  }

  function getSeq(el){
    const v = el.getAttribute("data-sticky-seq");
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }

  function layoutOnce(){
    const host = I.toasts;
    if (!host) return;

    lockHost(host);

    let items = Array.from(host.children);
    if (!items.length) return;

    // ✅ قطعی: ترتیب توست‌ها همیشه بر اساس __seq (جدیدتر بالاتر)
    items.sort((a, b) => getSeq(b) - getSeq(a));

    const heights = measureHeights(items);
    applyAbsoluteStack(items, heights);
  }

  function layout(){
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        requestAnimationFrame(layoutOnce);
      });
    });
  }

  I.layoutToasts = layout;

  const host = I.toasts;
  if (host) {
    const mo = new MutationObserver(() => layout());
    mo.observe(host, { childList: true });
  }

  window.addEventListener("resize", layout);
  layout();
})();