(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  I.enableDragFloating = (cardEl, model) => {
    let dragging = false;
    let pid = null;
    let startX = 0, startY = 0;
    let originL = 0, originT = 0;

    // Start dragging when clicking on the card (with header) excluding interactive elements.
    const onDown = (e) => {
      const target = e.target;
      if (!target) return;

      // 1. Check if the card has a header (and is draggable)
      if (!cardEl.classList.contains('sticky_cardWithHeader')) return;

      // 2. Skip drag if clicking on interactive elements
      if (target.closest(
        '.sticky_replyInput, .sticky_send, .sticky_todoInput, .sticky_todoAddBtn, .sticky_toolbarBtn, .sticky_color, .sticky_swatch, .sticky_resizeHandle, .sticky_editor, .sticky_editorWrap, .sticky_todoDelete, .sticky_todoCheckbox, .sticky_dock, .sticky_archive, .sticky_share, .sticky_close'
      )) return;

      // 3. Allow drag anywhere on the card (header required) except interactive controls.
      //    This is a relaxation to ensure drag works; header requirement via class remains intact.

      // Left mouse button or primary touch only
      if (e.button !== undefined && e.button !== 0) return;

      dragging = true;
      pid = e.pointerId;

      const rect = cardEl.getBoundingClientRect();
      // Record initial positions for computing deltas
      originL = rect.left;
      originT = rect.top;

      startX = e.clientX;
      startY = e.clientY;

      // Bring card to front when dragging
      cardEl.style.setProperty('--drag-z', String(++I.floatingZ));

      // Add a class so that CSS can change the cursor to grabbing
      cardEl.classList.add('sticky_dragging');

      try { cardEl.setPointerCapture(pid); } catch(_) {}
      e.preventDefault();
    };

    const onMove = (e) => {
      if (!dragging) return;
      if (pid !== null && e.pointerId !== pid) return;

      const dx = e.clientX - startX;
      const dy = e.clientY - startY;

      let nextL = Math.round(originL + dx);
      let nextT = Math.round(originT + dy);

      // Constrain movement within the bounds of the CRM area (or viewport)
      const bounds = (typeof I.getBounds === "function") ? I.getBounds() : { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight };
      const cardW = cardEl.offsetWidth;
      const cardH = cardEl.offsetHeight;

      // Convert right/left based on layout direction. We always set left/top
      // because cardEl.style.position is fixed and we only use absolute coords.
      const minL = bounds.left;
      const maxL = bounds.right - cardW;
      const minT = bounds.top;
      const maxT = bounds.bottom - cardH;

      if (nextL < minL) nextL = minL;
      if (nextL > maxL) nextL = maxL;
      if (nextT < minT) nextT = minT;
      if (nextT > maxT) nextT = maxT;

      // Determine document direction to set left/right and bottom positioning
      const dir = (typeof I.getDir === "function") ? I.getDir() : "rtl";
      const boundsRight = bounds.right;
      const boundsBottom = bounds.bottom;

      // Horizontal: use left offset for RTL; use right offset for LTR
      if (dir === "ltr") {
        const newRight = Math.round(boundsRight - (nextL + cardW));
        cardEl.style.setProperty('--drag-x', newRight + 'px');
        model.x = newRight;
      } else {
        cardEl.style.setProperty('--drag-x', nextL + 'px');
        model.x = nextL;
      }

      // Vertical: convert top offset to bottom offset
      const newBottom = Math.round(boundsBottom - (nextT + cardH));
      cardEl.style.setProperty('--drag-y', newBottom + 'px');
      model.y = newBottom;

      e.preventDefault();
    };

    const onUp = (e) => {
      if (!dragging) return;
      if (pid !== null && e.pointerId !== pid) return;

      dragging = false;

      try { cardEl.releasePointerCapture(pid); } catch(_) {}
      pid = null;

      // Remove the dragging class on release to restore cursor
      cardEl.classList.remove('sticky_dragging');

      model.state = "floating";

      // Persist updated coordinates via the store callback. Include all
      // relevant fields so the backend can fully update the card. See
      // joolio_sticky_cards.js for a list of properties. Avoid sending
      // undefined values; JSON.stringify will omit them.
      if (typeof I.STORE === "function") {
        I.STORE(I.buildFullPayload(model, { state: model.state }));
      }
    };

    cardEl.addEventListener("pointerdown", onDown, { passive: false });
    cardEl.addEventListener("pointermove", onMove, { passive: false });
    cardEl.addEventListener("pointerup", onUp);
    cardEl.addEventListener("pointercancel", onUp);
  };
})();