(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  if (I.__todoInstalled) return;
  I.__todoInstalled = true;

  const uid = () => "t" + Date.now() + "_" + Math.random().toString(16).slice(2);

  const t = (k) => (typeof I.t === "function" ? (I.t(k) || "") : "");

  function ensureTodos(model){
    if (!Array.isArray(model.todos)) model.todos = [];
  }
  
  function sync(model){
    if (typeof I.STORE === "function") I.STORE(model);
  }

  function safeText(v){
    return I.sanitize(String(v || "")).slice(0, 180);
  }

  function render(container, model){
    ensureTodos(model);
    container.innerHTML = "";

    const list = document.createElement("div");
    list.className = "sticky_todoList";

    model.todos.forEach((todo) => {
      const item = document.createElement("div");
      item.className = "sticky_todoItem";
      item.dataset.done = todo.done ? "1" : "0";

      const row = document.createElement("div");
      row.className = "sticky_todoRow";

      const check = document.createElement("div");
      check.className = "sticky_todoCheckbox";
      check.onclick = () => {
        todo.done = !todo.done;
        item.dataset.done = todo.done ? "1" : "0";
        sync(model);
      };

      const text = document.createElement("div");
      text.className = "sticky_todoText";
      text.textContent = safeText(todo.text);

      const del = document.createElement("button");
      del.className = "sticky_todoDelete";
      del.type = "button";
      del.textContent = "×";
      del.onclick = () => {
        model.todos = model.todos.filter((x) => x.tid !== todo.tid);
        render(container, model);
        sync(model);
      };

      row.append(check, text, del);
      item.appendChild(row);

      const childrenWrap = document.createElement("div");
      childrenWrap.className = "sticky_todoChildren";

      (todo.children || []).forEach((ch) => {
        const c = document.createElement("div");
        c.className = "sticky_todoChild";
        c.dataset.done = ch.done ? "1" : "0";

        const cRow = document.createElement("div");
        cRow.className = "sticky_todoRow sticky_todoRowChild";

        const cCheck = document.createElement("div");
        cCheck.className = "sticky_todoCheckbox";
        cCheck.onclick = () => {
          ch.done = !ch.done;
          c.dataset.done = ch.done ? "1" : "0";
          sync(model);
        };

        const cText = document.createElement("div");
        cText.className = "sticky_todoText";
        cText.textContent = safeText(ch.text);

        const cDel = document.createElement("button");
        cDel.className = "sticky_todoDelete";
        cDel.type = "button";
        cDel.textContent = "×";
        cDel.onclick = () => {
          todo.children = (todo.children || []).filter((x) => x.tid !== ch.tid);
          render(container, model);
          sync(model);
        };

        cRow.append(cCheck, cText, cDel);
        c.appendChild(cRow);
        childrenWrap.appendChild(c);
      });

      const addChild = document.createElement("div");
      addChild.className = "sticky_todoAddInline";
      addChild.innerHTML = `
        <input class="sticky_todoInput" />
        <button class="sticky_todoAddBtn" type="button">+</button>
      `;

      const childInput = addChild.querySelector(".sticky_todoInput");
      childInput.setAttribute("placeholder", t("todo_child_placeholder"));

      const childBtn = addChild.querySelector(".sticky_todoAddBtn");
      childBtn.onclick = () => {
        const val = safeText(childInput.value).trim();
        if (!val) return;
        todo.children = todo.children || [];
        todo.children.push({ tid: uid(), text: val, done: false });
        childInput.value = "";
        render(container, model);
        sync(model);
      };

      childrenWrap.appendChild(addChild);
      item.appendChild(childrenWrap);
      list.appendChild(item);
    });

    container.appendChild(list);

    const addParent = document.createElement("div");
    addParent.className = "sticky_todoAddInline";
    addParent.innerHTML = `
      <input class="sticky_todoInput" />
      <button class="sticky_todoAddBtn" type="button">+</button>
    `;

    const parentInput = addParent.querySelector(".sticky_todoInput");
    parentInput.setAttribute("placeholder", t("todo_placeholder"));

    const parentBtn = addParent.querySelector(".sticky_todoAddBtn");
    parentBtn.onclick = () => {
      const val = safeText(parentInput.value).trim();
      if (!val) return;
      model.todos.push({ tid: uid(), text: val, done: false, children: [] });
      parentInput.value = "";
      render(container, model);
      sync(model);
    };

    container.appendChild(addParent);
  }

  const _toast = I.buildToastCard;
  const _float = I.buildFloatingCard;

  I.buildToastCard = (m) => {
    const c = _toast(m);
    // Only attach todo content if the todo segment is enabled
    if (!m.segments || m.segments.todo !== false) {
      const w = document.createElement("div");
      w.className = "sticky_todoWrap";
      c.appendChild(w);
      render(w, m);
    }
    return c;
  };

  I.buildFloatingCard = (m) => {
    const c = _float(m);
    if (!m.segments || m.segments.todo !== false) {
      const w = document.createElement("div");
      w.className = "sticky_todoWrap";
      c.appendChild(w);
      render(w, m);
    }
    return c;
  };
})();