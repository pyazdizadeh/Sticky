(() => {
  const api = window.JOOLIOSticky;
  const I = api?.__internal;
  if (!I) return;

  if (I.__colorInstalled) return;
  I.__colorInstalled = true;

  /* Define a palette of ten bright and distinct colours. Each key matches
     a corresponding CSS rule in the card and pinned stylesheets. */
  // Define the palette with green first so that it becomes the default
  // colour when a new card is created without an explicit colour. The order
  // of this array determines which colour the palette module selects for
  // cards lacking a specified colour. Placing green first aligns with
  // the default colour set in createModel.
  const COLORS = [
    { key: "green",  label: "Green"  },
    { key: "red",    label: "Red"    },
    { key: "orange", label: "Orange" },
    { key: "yellow", label: "Yellow" },
    { key: "blue",   label: "Blue"   },
    { key: "purple", label: "Purple" },
    { key: "pink",   label: "Pink"   },
    { key: "cyan",   label: "Cyan"   },
    { key: "lime",   label: "Lime"   },
    { key: "violet", label: "Violet" }
  ];

  let openCard = null;

  function persist(model) {
    if (typeof I.updateSticky === "function") I.updateSticky(model);
    else if (typeof I.UPDATE === "function") I.UPDATE(model);
    else if (typeof I.STORE === "function") I.STORE(model);
  }

  function closePalette() {
    if (!openCard) return;
    openCard.classList.remove("sticky_paletteOpen");
    openCard = null;
  }

  document.addEventListener("pointerdown", (e) => {
    if (!openCard) return;
    if (openCard.contains(e.target)) return;
    closePalette();
  }, true);

  function ensurePalette(cardEl, model) {
    // Skip palette injection entirely if the header segment is disabled
    if (model?.segments && model.segments.header === false) return;

    if (!cardEl || cardEl.querySelector(".sticky_color")) return;

    // Default to the first colour in the palette when no colour is set on
    // the model. This keeps the palette in sync with the new colour list.
    const defaultKey = Array.isArray(COLORS) && COLORS.length > 0 ? COLORS[0].key : 'red';
    const init = String(model?.color || defaultKey);
    cardEl.setAttribute("data-sticky-color", init);

    const closeBtn = cardEl.querySelector(".sticky_close");
    if (!closeBtn) return;

    const colorBtn = document.createElement("button");
    colorBtn.type = "button";
    colorBtn.className = "sticky_color";
    colorBtn.setAttribute("aria-label", "color");
    // Set a tooltip on the palette button using the i18n label if available.
    try {
      const lbl = (typeof I.t === 'function' ? I.t('aria_color') : '') || '';
      if (lbl) colorBtn.setAttribute('title', lbl);
    } catch (_) {}
    // Use the custom palette SVG icon instead of a text emoji. This
    // matches the look of other header icons and ensures consistent
    // sizing. The SVG uses a pure white stroke so the glyph inherits
    // the button’s colour via CSS.
    colorBtn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none"><path d="M17 8.5C11.7533 8.5 7.5 12.7533 7.5 18C7.5 23.2467 11.7533 27.5 17 27.5H19.2C20.5255 27.5 21.6 26.4255 21.6 25.1C21.6 24.2849 21.2796 23.5032 20.7094 22.9294C20.1352 22.3596 19.8148 21.5779 19.8148 20.7628C19.8148 19.0849 21.175 17.7246 22.8529 17.7246H24C26.4853 17.7246 28.5 15.7099 28.5 13.2246C28.5 10.4236 23.7467 8.5 17 8.5Z" stroke="#FFFFFF" stroke-width="2" stroke-linejoin="round"/><path d="M11.5 18.5H11.6" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/><path d="M14.5 13.5H14.6" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/><path d="M19.5 12.5H19.6" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/><path d="M23 14.5H23.1" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/></svg>`;

    const palette = document.createElement("div");
    palette.className = "sticky_palette";
    palette.setAttribute("aria-hidden", "true");

    const inner = document.createElement("div");
    inner.className = "sticky_paletteInner";

    COLORS.forEach((c) => {
      const sw = document.createElement("button");
      sw.type = "button";
      sw.className = "sticky_swatch";
      sw.setAttribute("data-color", c.key);
      sw.setAttribute("aria-label", c.label);

      sw.addEventListener("click", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();

        model.color = c.key;
        cardEl.setAttribute("data-sticky-color", c.key);

        persist(model);
        closePalette();

        // Synchronize pinned tab color when a color is selected. Find the
        // pinned tab with matching sticky_id and update its data-sticky-color
        // attribute so its appearance matches the card. This ensures that
        // pinned tabs remain in sync when the card color changes.
        try {
          const pinnedTabs = document.querySelectorAll('.sticky_pinnedTab');
          pinnedTabs.forEach((tab) => {
            if (tab.getAttribute('data-sticky-id') === String(model.sticky_id)) {
              tab.setAttribute('data-sticky-color', c.key);
            }
          });
        } catch (_) {}
      });

      inner.appendChild(sw);
    });

    palette.appendChild(inner);

    closeBtn.insertAdjacentElement("afterend", colorBtn);
    cardEl.appendChild(palette);

    colorBtn.addEventListener("click", (ev) => {
      ev.preventDefault();
      ev.stopPropagation();

      if (openCard && openCard !== cardEl) openCard.classList.remove("sticky_paletteOpen");
      const isOpen = cardEl.classList.toggle("sticky_paletteOpen");
      openCard = isOpen ? cardEl : null;
    });
  }

  const _toast = I.buildToastCard;
  const _float = I.buildFloatingCard;

  I.buildToastCard = (m) => {
    const c = _toast(m);
    ensurePalette(c, m);
    return c;
  };

  I.buildFloatingCard = (m) => {
    const c = _float(m);
    ensurePalette(c, m);
    return c;
  };
})();